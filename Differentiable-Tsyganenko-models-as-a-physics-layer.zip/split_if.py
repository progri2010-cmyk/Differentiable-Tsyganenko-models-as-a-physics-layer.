"""Turn a top-level  'if COND: A else: B'  block (4-space indent) inside a function into two nested
functions evaluated only on their own subsets of points (xp.branch), outputs (bx,by,bz) combined."""
import re
def split_if(s, cond_line, args, outs='bx,by,bz', func=None):
    i0 = s.index(cond_line) if func is None else s.index(cond_line, s.index('def ' + func + '('))
    m = re.match(r'    if (.*):\s*(#.*)?$', cond_line.rstrip('\n'))
    cond = m.group(1)
    j = i0 + len(cond_line)
    lines = s[j:].split('\n')
    body1, body2, k = [], [], 0
    while not lines[k].startswith('    else:'):
        body1.append(lines[k]); k += 1
    k += 1
    while k < len(lines) and (lines[k].startswith('        ') or lines[k].strip() == ''):
        body2.append(lines[k]); k += 1
    while body2 and body2[-1].strip() == '': body2.pop()
    end = j + len('\n'.join(lines[:k]))
    a = ','.join(args)
    new = (f'    _cond = {cond}\n    _n = _cond.shape[0]\n'
           f'    def _b1({a}):\n' + '\n'.join(body1) + f'\n        return {outs}\n'
           f'    def _b2({a}):\n' + '\n'.join(body2) + f'\n        return {outs}\n'
           f'    {outs} = np.combine(_n, np.branch(_cond, _b1, {a}), np.branch(~_cond, _b2, {a}))\n')
    return s[:i0] + new + s[end:]
