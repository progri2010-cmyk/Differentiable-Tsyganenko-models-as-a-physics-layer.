import json, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': '#52514e', 'axes.spines.top': False, 'axes.spines.right': False})
C1, C2, C3 = '#2a78d6', '#eb6834', '#1baf7a'
e4 = json.load(open('results_e4.json'))['rows']; e5b = json.load(open('results_e5b.json')); e6 = json.load(open('results_e6.json'))
fig, ax = plt.subplots(1, 2, figsize=(9, 3.4), constrained_layout=True)
N = [r['N'] for r in e4]
ax[0].loglog(N, [r['t_geopack_s'] for r in e4], 'o-', c=C2, lw=2, ms=6, label='geopack (cikël skalar)')
ax[0].loglog(N, [r['t_torch_s'] for r in e4], 's-', c=C1, lw=2, ms=6, label='PyTorch, fusha')
ax[0].loglog(N, [r['t_torch_jac_s'] for r in e4], '^-', c=C3, lw=2, ms=6, label='PyTorch, fusha + Jakobiani 3×3')
ax[0].set_xlabel('numri i pikave N'); ax[0].set_ylabel('koha (s)'); ax[0].set_title('(a) Vlerësimi i T89c, CPU 2 fije, float64', fontsize=9)
ax[0].legend(frameon=False, fontsize=8); ax[0].grid(alpha=.25, lw=.5)
n = [r['n_lines'] for r in e5b]
ax[1].loglog(n, [r['t_geopack_s'] for r in e5b], 'o-', c=C2, lw=2, ms=6, label='geopack.trace')
ax[1].loglog(n, [r['t_torch_s'] for r in e5b], 's-', c=C1, lw=2, ms=6, label='gjurmim i grupuar (PyTorch)')
ax[1].set_xlabel('numri i vijave të fushës'); ax[1].set_ylabel('koha (s)'); ax[1].set_title('(b) Gjurmimi IGRF + T89c deri në r = 1 Re', fontsize=9)
ax[1].legend(frameon=False, fontsize=8); ax[1].grid(alpha=.25, lw=.5)
fig.savefig('fig_performance.png', dpi=180)

fig, ax = plt.subplots(1, 2, figsize=(9, 3.2), constrained_layout=True)
sig = [1, 2, 5, 10]
for v, mk, lab in (('A', 'o', 'variant A (s, ψ)'), ('B', 's', 'variant B (s, ψ, κ$_T$, κ$_{RC}$)')):
    for j, (axx, unit) in enumerate(zip(ax, ('nivel', '°'))):
        mc = [e6[f'{v}_sigma{s}']['rmse'][j] for s in sig]; lp = [e6[f'{v}_sigma{s}']['laplace_sd'][j] for s in sig]
        c = C1 if v == 'A' else C2
        axx.loglog(sig, mc, mk + '-', c=c, lw=2, ms=6, label=f'{lab}: RMSE Monte Carlo')
        axx.loglog(sig, lp, mk + '--', c=c, lw=1.2, ms=6, mfc='none', label=f'{lab}: σ Laplace (AD)')
ax[0].set_title('(a) niveli i vazhdueshëm i aktivitetit s', fontsize=9); ax[0].set_ylabel('gabimi (njësi niveli)')
ax[1].set_title('(b) këndi i pjerrësisë së dipolit ψ', fontsize=9); ax[1].set_ylabel('gabimi (°)')
for a in ax: a.set_xlabel('zhurma σ (nT)'); a.grid(alpha=.25, lw=.5)
ax[0].legend(frameon=False, fontsize=7)
fig.savefig('fig_inverse.png', dpi=180); print('ok')
