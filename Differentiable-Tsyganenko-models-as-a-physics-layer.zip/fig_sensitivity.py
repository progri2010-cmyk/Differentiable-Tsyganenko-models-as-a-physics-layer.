"""Autodiff sensitivity maps d|B|/dPdyn and d|B|/dDst in the noon-midnight meridian (T96, T04)."""
import numpy as np, torch, matplotlib, warnings; matplotlib.use('Agg'); warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from tsyg import t96, t04
torch.set_num_threads(2)
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': '#52514e'})
xs = np.linspace(-15, 10, 126); zs = np.linspace(-10, 10, 101)
XX, ZZ = np.meshgrid(xs, zs); n = XX.size
X, Z = torch.tensor(XX.ravel()), torch.tensor(ZZ.ravel()); Y = torch.zeros(n, dtype=torch.float64)
base = {'T96': (t96, [3.0, -50., 3.0, -4.0] + [0.]*6), 'T04': (t04, [3.0, -50., 3.0, -4.0, 0.8, 0.9, 1.1, 1.2, 1.3, 1.4])}
fig, axs = plt.subplots(2, 2, figsize=(9.5, 6.4), sharex=True, sharey=True, constrained_layout=True)
for r, (lab, (f, par)) in enumerate(base.items()):
    pd = torch.full((n,), par[0], dtype=torch.float64, requires_grad=True)
    ds = torch.full((n,), par[1], dtype=torch.float64, requires_grad=True)
    B = torch.stack(f([pd, ds] + par[2:], 0.0, X, Y, Z), 1)
    Bm = B.norm(dim=1)
    gp, gd = torch.autograd.grad(Bm.sum(), (pd, ds))
    for c, (g, name, unit, vm) in enumerate(((gp, 'P$_{dyn}$', 'nT/nPa', 8.0), (gd, 'Dst', 'nT/nT', 0.6))):
        G = g.numpy().reshape(XX.shape); G[np.hypot(XX, ZZ) < 2.0] = np.nan
        ax = axs[r, c]
        im = ax.pcolormesh(XX, ZZ, G, cmap='RdBu_r', norm=TwoSlopeNorm(0, -vm, vm), shading='auto', rasterized=True)
        ax.add_patch(plt.Circle((0, 0), 1, color='#52514e')); ax.set_aspect('equal')
        ax.set_title(f'{lab}:  ∂|B$_{{ext}}$|/∂{name}', fontsize=9)
        cb = fig.colorbar(im, ax=ax, shrink=0.9, extend='both'); cb.set_label(unit)
        if r == 1: ax.set_xlabel('X$_{GSM}$ (Re)')
        if c == 0: ax.set_ylabel('Z$_{GSM}$ (Re)')
fig.savefig('fig_sensitivity.png', dpi=170); print('ok')
