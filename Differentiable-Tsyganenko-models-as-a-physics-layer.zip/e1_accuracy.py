"""E1: pointwise agreement of the PyTorch port with geopack (T89c, dipole, IGRF)."""
import numpy as np, torch, datetime, json, time
from geopack import geopack as gp
from geopack.t89 import t89 as t89_ref
import tsyg_torch as tt
rng = np.random.default_rng(1)

def sample(n):
    pts = []
    while len(pts) < n:
        x = rng.uniform(-60, 12, n); y = rng.uniform(-25, 25, n); z = rng.uniform(-20, 20, n)
        r = np.sqrt(x*x+y*y+z*z); ok = r > 1.5
        pts += list(zip(x[ok], y[ok], z[ok]))
    return np.array(pts[:n])

N = 20000
P = sample(N); PS = rng.uniform(np.radians(-35), np.radians(35), N)
res = {}
for iopt in range(1, 8):
    ref = np.array([t89_ref(iopt, PS[i], *P[i]) for i in range(N)])
    a = tt.t89_coeffs(iopt)
    out = torch.stack(tt.t89(torch.tensor(P[:,0]), torch.tensor(P[:,1]), torch.tensor(P[:,2]), torch.tensor(PS), a), -1).numpy()
    err = np.linalg.norm(out-ref, axis=1); mag = np.linalg.norm(ref, axis=1)
    res[f't89_iopt{iopt}'] = dict(max_abs_nT=float(err.max()), max_rel=float((err/mag).max()), median_B_nT=float(np.median(mag)))
    print(iopt, res[f't89_iopt{iopt}'])

# internal fields at a fixed epoch
ut = (datetime.datetime(2015,3,17,12)-datetime.datetime(1970,1,1)).total_seconds()
ig = tt.IGRF.from_geopack(ut)
Pi = P[:5000]
Pi = Pi * np.where(np.linalg.norm(Pi,axis=1) > 15, 15/np.linalg.norm(Pi,axis=1), 1)[:,None]   # keep internal-field test inside 15 Re
Pi = Pi[np.linalg.norm(Pi,axis=1) > 1.0]
# also add near-surface points
u = rng.normal(size=(3000,3)); u /= np.linalg.norm(u,axis=1)[:,None]; Pi = np.vstack([Pi, u*rng.uniform(1.0,1.5,(3000,1))])
ref_ig = np.array([gp.igrf_gsm(*p) for p in Pi]); ref_dp = np.array([gp.dip(*p) for p in Pi])
X = [torch.tensor(Pi[:,k]) for k in range(3)]
out_ig = torch.stack(ig.gsm(*X, truncate='geopack'), -1).numpy()
out_ig_full = torch.stack(ig.gsm(*X), -1).numpy()
out_dp = torch.stack(tt.dipole(*X, ig.ps, ig.dipmom), -1).numpy()
for name, o, r in [('igrf_geopack_trunc', out_ig, ref_ig), ('igrf_full_n13', out_ig_full, ref_ig), ('dipole', out_dp, ref_dp)]:
    e = np.linalg.norm(o-r,axis=1); m = np.linalg.norm(r,axis=1)
    res[name] = dict(max_abs_nT=float(e.max()), max_rel=float((e/m).max()), median_B_nT=float(np.median(m)))
    print(name, res[name])
json.dump(res, open('results_e1.json','w'), indent=1)
