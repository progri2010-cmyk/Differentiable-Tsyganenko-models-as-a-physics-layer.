"""E9: inverse identification of the T96 / T04 driving parameters (and the dipole tilt) from noisy
synthetic B_ext along spacecraft orbits, by L-BFGS through the differentiable models, with the
Laplace (Gauss-Newton) covariance from the autodiff Jacobian as an identifiability diagnostic."""
import numpy as np, torch, json, time, warnings
warnings.filterwarnings('ignore'); torch.set_num_threads(2)
from tsyg.t96 import t96; from tsyg.t04 import t04
rng = np.random.default_rng(9)
P = torch.tensor(np.load('orbit_points.npy')); P = P[P[:, 0] > -14.5]
X, Y, Z = P.T
cases = {
  't96': dict(f=t96, names=['Pdyn', 'Dst', 'By', 'Bz', 'tilt'], truth=[4.0, -60., 5.0, -6.0, np.radians(12)],
              init=[2.0, -20., 0.5, 0.5, 0.0], trials=8, sigmas=(1.0, 2.0, 5.0, 10.0)),
  't04': dict(f=t04, names=['Pdyn', 'Dst', 'By', 'Bz', 'W1', 'W2', 'W3', 'W4', 'W5', 'W6', 'tilt'],
              truth=[4.0, -60., 5.0, -6.0, 0.8, 0.9, 1.1, 1.2, 1.3, 1.4, np.radians(12)],
              init=[2.0, -20., 0.5, 0.5] + [0.5]*6 + [0.0], trials=5, sigmas=(2.0, 10.0))}

def unpack(u, case):   # Pdyn and W_k are positive: optimise their logarithms
    n = len(case['names']); out = []
    for k, nm in enumerate(case['names']):
        out.append(torch.exp(u[k]) if (nm == 'Pdyn' or nm.startswith('W')) else u[k])
    return out
def pack(v, case):
    return torch.tensor([np.log(x) if (nm == 'Pdyn' or nm.startswith('W')) else x for x, nm in zip(v, case['names'])], dtype=torch.float64)
def field(v, case):
    prm = v[:-1] + [0.] * (11 - len(v)); prm = prm[:10]
    return torch.stack(case['f'](prm, v[-1], X, Y, Z), 1)

def fit(obs, case):
    u = pack(case['init'], case).requires_grad_(True)
    opt = torch.optim.LBFGS([u], lr=1, max_iter=500, tolerance_grad=1e-10, tolerance_change=1e-14, line_search_fn='strong_wolfe')
    nfev = [0]
    def closure():
        opt.zero_grad(); nfev[0] += 1
        L = ((field(unpack(u, case), case) - obs) ** 2).mean(); L.backward(); return L
    opt.step(closure)
    return [float(t) for t in unpack(u.detach(), case)], nfev[0]

def laplace(v, case, sigma):
    th = torch.tensor(v, dtype=torch.float64)
    J = torch.autograd.functional.jacobian(lambda t: field(list(t), case).reshape(-1), th)   # (3N, p)
    F = J.T @ J
    C = sigma ** 2 * torch.linalg.inv(F)
    sd = C.diag().sqrt(); corr = C / torch.outer(sd, sd)
    ev = torch.linalg.eigvalsh(F / torch.outer(th.abs().clamp(min=1e-3)**-1, th.abs().clamp(min=1e-3)**-1))
    return sd.numpy(), corr.numpy(), float(ev.max() / ev.min())

res = {'n_points': int(P.shape[0])}
for name, case in cases.items():
    B0 = field([torch.tensor(v, dtype=torch.float64) for v in case['truth']], case).detach()
    out = {}
    for sigma in case['sigmas']:
        E, NF, TT = [], [], []
        for k in range(case['trials']):
            obs = B0 + sigma * torch.tensor(rng.normal(size=B0.shape))
            t0 = time.perf_counter(); v, nf = fit(obs, case); TT.append(time.perf_counter() - t0); E.append(v); NF.append(nf)
            print('  fit', name, sigma, k, round(TT[-1], 1), 's', nf, 'evals', np.round(v, 3).tolist(), flush=True)
        E = np.array(E); T = np.array(case['truth'])
        sd, corr, cond = laplace(case['truth'], case, sigma)
        conv = np.array([np.degrees(1) if n == 'tilt' else 1. for n in case['names']])
        out[f'sigma{sigma:g}'] = dict(truth=(T*conv).tolist(), mean=(E.mean(0)*conv).tolist(), rmse=(np.sqrt(((E-T)**2).mean(0))*conv).tolist(),
                                      mc_sd=(E.std(0)*conv).tolist(), laplace_sd=(sd*conv).tolist(),
                                      mean_evals=float(np.mean(NF)), mean_time_s=float(np.mean(TT)), trials=case['trials'])
        print(name, sigma, {kk: np.round(vv, 3).tolist() if isinstance(vv, list) else round(vv, 3) for kk, vv in out[f'sigma{sigma:g}'].items()}, flush=True)
    out['names'] = case['names']; out['laplace_corr_sigma1'] = laplace(case['truth'], case, 1.0)[1].round(3).tolist()
    out['fisher_condition_number_relative'] = laplace(case['truth'], case, 1.0)[2]
    res[name] = out
json.dump(res, open('results_e9_inverse_new.json', 'w'), indent=1)
