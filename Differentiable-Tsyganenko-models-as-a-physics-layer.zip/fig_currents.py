"""Figure: dawn-dusk current density j_y = (curl B)_y / mu0 from autodiff, noon-midnight meridian (y=0)."""
import numpy as np, torch, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
import tsyg_torch as tt
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': '#52514e', 'axes.labelcolor': '#0b0b0b'})
xs = np.linspace(-40, 10, 401); zs = np.linspace(-12, 12, 193)
XX, ZZ = np.meshgrid(xs, zs)
pos = torch.tensor(np.stack([XX.ravel(), np.zeros(XX.size), ZZ.ravel()], 1))
fig, axs = plt.subplots(2, 3, figsize=(10, 4.4), sharex=True, sharey=True, constrained_layout=True)
vmax = 8.0
for c, iopt in enumerate((1, 4, 7)):
    for r, psd in enumerate((0, 25)):
        a = tt.t89_coeffs(iopt); ps = np.radians(psd)
        _, J = tt.field_jacobian(lambda x, y, z: tt.t89(x, y, z, ps, a), pos)
        div, curl = tt.div_curl(J)
        jy = tt.current_density_nA_m2(curl[:, 1]).numpy().reshape(XX.shape)
        jy[np.hypot(XX, ZZ) < 3] = np.nan
        ax = axs[r, c]
        im = ax.pcolormesh(XX, ZZ, jy, cmap='RdBu_r', norm=TwoSlopeNorm(0, -vmax, vmax), shading='auto', rasterized=True)
        ax.add_patch(plt.Circle((0, 0), 1, color='#52514e'))
        ax.set_title(f'iopt={iopt},  ψ={psd}°   max|div B|={div.abs().max():.0e} nT/Re', fontsize=8)
        ax.set_aspect('equal')
        if r == 1: ax.set_xlabel('X$_{GSM}$ (Re)')
        if c == 0: ax.set_ylabel('Z$_{GSM}$ (Re)')
cb = fig.colorbar(im, ax=axs, shrink=0.85, extend='both'); cb.set_label('j$_y$ (nA/m$^2$)')
fig.savefig('fig_currents.png', dpi=180)
print('ok')
