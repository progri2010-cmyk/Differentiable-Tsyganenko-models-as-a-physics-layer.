"""Shared vectorization edits for the T01 (extall) and T04 (extern) top-level functions."""
import sys, re
p = sys.argv[1]; s = open(p).read()
# 1. clock angle
if '(byimf == 0) & (bzimf == 0)' in s:
  i0 = s.index('    if (byimf == 0) & (bzimf == 0):\n        theta = 0.')
  i1 = s.index('    ct=np.cos(theta)', i0)
  s = s[:i0] + '''    zero_imf = (np._t(byimf) == 0) & (np._t(bzimf) == 0)
    theta = np.arctan2(np.where(zero_imf, 0., byimf), np.where(zero_imf, 1., bzimf))
    theta = np.where(zero_imf, 0., np.where(theta <= 0, theta + 2*np.pi, theta))

''' + s[i1:]
# 2. fixed-point iteration for unwarped coordinates, per-point convergence like the scalar code
i0 = s.index('    dd = 1.\n    while dd > 1e-6:')
i1 = s.index('    rho2=y**2+zss**2', i0)
s = s[:i0] + '''    # per-point iteration: a point stops updating after the step in which its change dd <= 1e-6,
    # exactly as in the scalar loop
    xss = np._t(x) + 0*np._t(z); zss = np._t(z) + 0*np._t(x)
    active = torch.ones_like(xss, dtype=torch.bool)
    for _it in range(200):
        rh=rh0+rh2*(zss/r)**2
        sinpsas=sps/(1+(r/rh)**3)**0.33333333
        cospsas=np.sqrt(1-sinpsas**2)
        zn=x*sinpsas+z*cospsas
        xn=x*cospsas-z*sinpsas
        dd=np.abs(xn-xss)+np.abs(zn-zss)
        xss = np.where(active, xn, xss); zss = np.where(active, zn, zss)
        active = active & (dd > 1e-6)
        if not bool(active.any()): break

''' + s[i1:]
s = s.replace('    if xmxm < 0: xmxm = 0   # the boundary', '    xmxm = np.maximum(xmxm, 0.)   # the boundary')
# 3. regions: evaluate the magnetospheric model at a harmless interior point outside the layer
s = re.sub(r'    if sigma < \(s0\+dsig\):[^\n]*\n', '''    _inl = sigma < (s0+dsig)
    xx = np.where(_inl, xx, 3.0); yy = np.where(_inl, yy, 0.5); zz = np.where(_inl, zz, 0.5)
    if True:
''', s, count=1)
i0 = s.index('        if sigma < (s0-dsig):   # (x,y,z) is inside the magnetosphere')
i1 = s.index('    return bx,by,bz', i0)
s = s[:i0] + '''        fint=0.5*(1.-(sigma-s0)/dsig)
        fext=0.5*(1.+(sigma-s0)/dsig)
        qx,qy,qz = dipole(ps,x,y,z)
        inside = sigma < (s0-dsig)
        bx = np.where(inside, bbx, np.where(_inl, (bbx+qx)*fint+oimfx*fext-qx, oimfx-qx))
        by = np.where(inside, bby, np.where(_inl, (bby+qy)*fint+oimfy*fext-qy, oimfy-qy))
        bz = np.where(inside, bbz, np.where(_inl, (bbz+qz)*fint+oimfz*fext-qz, oimfz-qz))

''' + s[i1:]
if 'import torch' not in s:
    s = s.replace('from . import xp as np', 'import torch\nfrom . import xp as np', 1)
open(p, 'w').write(s); print('converted', p)
