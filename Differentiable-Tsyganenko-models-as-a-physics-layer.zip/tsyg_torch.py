"""
tsyg_torch.py — differentiable, vectorized implementation of the Tsyganenko T89c
external magnetospheric field model, the geodipole and the IGRF internal field,
written in PyTorch (float64 by default).

Every function accepts tensors of arbitrary (broadcastable) shape, so a single call
evaluates the field at millions of points, and every output is differentiable with
respect to position, dipole tilt, the continuous activity level, and all 30 T89
model coefficients (autograd, forward- or reverse-mode, including higher order).

The arithmetic follows N. A. Tsyganenko's FORTRAN T89c (release Feb 1996) as ported
to Python in the `geopack` package (S. Tian), term by term, so that results agree
with the reference to round-off.  Author of the PyTorch port: PINN-4-Tsyganenko study.
"""
from __future__ import annotations
import math
import torch

DTYPE = torch.float64

# ----------------------------------------------------------------------------------
# T89c coefficient table: 30 parameters x 7 activity levels (iopt = 1..7)
# iopt: 1 -> Kp 0,0+ ; 2 -> 1-,1,1+ ; 3 -> 2-,2,2+ ; ... ; 7 -> >= 6-
# ----------------------------------------------------------------------------------
_T89_PARAM = [
    -116.53, -10719., 42.375, 59.753, -11363., 1.7844, 30.268,
    -0.35372E-01, -0.66832E-01, 0.16456E-01, -1.3024, 0.16529E-02,
    0.20293E-02, 20.289, -0.25203E-01, 224.91, -9234.8, 22.788, 7.8813,
    1.8362, -0.27228, 8.8184, 2.8714, 14.468, 32.177, 0.01, 0.0,
    7.0459, 4.0, 20.0, -55.553, -13198., 60.647, 61.072, -16064.,
    2.2534, 34.407, -0.38887E-01, -0.94571E-01, 0.27154E-01, -1.3901,
    0.13460E-02, 0.13238E-02, 23.005, -0.30565E-01, 55.047, -3875.7,
    20.178, 7.9693, 1.4575, 0.89471, 9.4039, 3.5215, 14.474, 36.555,
    0.01, 0.0, 7.0787, 4.0, 20.0, -101.34, -13480., 111.35, 12.386, -24699.,
    2.6459, 38.948, -0.34080E-01, -0.12404, 0.29702E-01, -1.4052,
    0.12103E-02, 0.16381E-02, 24.49, -0.37705E-01, -298.32, 4400.9, 18.692,
    7.9064, 1.3047, 2.4541, 9.7012, 7.1624, 14.288, 33.822, 0.01, 0.0, 6.7442,
    4.0, 20.0, -181.69, -12320., 173.79, -96.664, -39051., 3.2633, 44.968,
    -0.46377E-01, -0.16686, 0.048298, -1.5473, 0.10277E-02, 0.31632E-02,
    27.341, -0.50655E-01, -514.10, 12482., 16.257, 8.5834, 1.0194, 3.6148,
    8.6042, 5.5057, 13.778, 32.373, 0.01, 0.0, 7.3195, 4.0, 20.0, -436.54,
    -9001.0, 323.66, -410.08, -50340., 3.9932, 58.524, -0.38519E-01,
    -0.26822, 0.74528E-01, -1.4268, -0.10985E-02, 0.96613E-02, 27.557,
    -0.56522E-01, -867.03, 20652., 14.101, 8.3501, 0.72996, 3.8149, 9.2908,
    6.4674, 13.729, 28.353, 0.01, 0.0, 7.4237, 4.0, 20.0, -707.77, -4471.9,
    432.81, -435.51, -60400., 4.6229, 68.178, -0.88245E-01, -0.21002,
    0.11846, -2.6711, 0.22305E-02, 0.10910E-01, 27.547, -0.54080E-01,
    -424.23, 1100.2, 13.954, 7.5337, 0.89714, 3.7813, 8.2945, 5.174, 14.213,
    25.237, 0.01, 0.0, 7.0037, 4.0, 20.0, -1190.4, 2749.9, 742.56, -1110.3,
    -77193., 7.6727, 102.05, -0.96015E-01, -0.74507, 0.11214, -1.3614,
    0.15157E-02, 0.22283E-01, 23.164, -0.74146E-01, -2219.1, 48253.,
    12.714, 7.6777, 0.57138, 2.9633, 9.3909, 9.7263, 11.123, 21.558, 0.01,
    0.0, 4.4518, 4.0, 20.0]


def t89_table(dtype=DTYPE, device=None) -> torch.Tensor:
    """Return the (7, 30) T89c coefficient table; row i is iopt = i+1."""
    return torch.tensor(_T89_PARAM, dtype=dtype, device=device).reshape(7, 30)


def t89_coeffs(iopt: int | None = None, level=None, dtype=DTYPE, device=None) -> torch.Tensor:
    """
    Coefficient vector a (30,) for T89c.

    iopt  : integer 1..7 -> exact tabulated coefficients (as in the original model).
    level : continuous activity level s in [1, 7] (tensor or float, any shape);
            coefficients are linearly interpolated between neighbouring iopt columns,
            which makes the model differentiable with respect to activity.
            Returns shape level.shape + (30,).
    """
    tab = t89_table(dtype, device)
    if iopt is not None:
        return tab[int(iopt) - 1]
    s = torch.as_tensor(level, dtype=dtype, device=device)
    s = s.clamp(1.0, 7.0)
    i0 = torch.clamp(torch.floor(s).long() - 1, 0, 5)          # lower node index 0..5
    f = (s - 1.0 - i0.to(dtype)).unsqueeze(-1)                  # fraction in [0,1]
    return tab[i0] * (1 - f) + tab[i0 + 1] * f


def kp_to_level(kp):
    """Map a (continuous) Kp index to the continuous T89 level s = clip(Kp,0,6)+1."""
    return torch.as_tensor(kp, dtype=DTYPE).clamp(0.0, 6.0) + 1.0


# ----------------------------------------------------------------------------------
# T89c external field
# ----------------------------------------------------------------------------------
def t89(x, y, z, ps, a):
    """
    T89c external field in GSM, nT.

    x, y, z : GSM position in Re (tensors, broadcastable)
    ps      : dipole tilt angle in radians (tensor/float, broadcastable)
    a       : coefficients, shape (30,) or (..., 30) broadcastable with x
    returns (bx, by, bz)
    """
    x, y, z = (torch.as_tensor(v, dtype=DTYPE) for v in (x, y, z))
    ps = torch.as_tensor(ps, dtype=DTYPE)
    a = torch.as_tensor(a, dtype=DTYPE)
    A = a.unbind(-1)

    # fixed constants of the model
    a02, xlw2, yn, rpi, rt = 25., 170., 30.0, 0.318309890, 30.
    xd, xld2 = 0., 40.
    sxc, xlwc2 = 4., 50.

    dyc = A[29]
    dx = A[17]
    ha02 = 0.5 * a02
    rdyc2 = 1.0 / dyc ** 2
    hlwc2m = -0.5 * xlwc2
    drdyc2 = -2.0 * rdyc2
    hxlw2m = -0.5 * xlw2
    adr, d0, dd, rc, g, at = A[18], A[19], A[20], A[21], A[22], A[23]
    dt = d0
    p, delt, q, sx, gam = A[24], A[25], A[26], A[27], A[28]
    hxld2m = -0.5 * xld2
    dbldel = 2.0 * delt
    w1 = -0.5 / dx
    w2 = w1 * 2.0
    w4 = -1.0 / 3.0
    w3 = w4 / dx
    w5 = -0.5
    w6 = -3.0
    ak1, ak2, ak3, ak4, ak5, ak6, ak7, ak8, ak9, ak10, ak11, ak12, ak13, ak14, ak15, ak16, ak17 = A[0:17]
    ak610 = ak6 * w1 + ak10 * w5
    ak711 = ak7 * w2 - ak11
    ak812 = ak8 * w2 + ak12 * w6
    ak913 = ak9 * w3 + ak13 * w4

    tlt2 = ps ** 2
    sps = torch.sin(ps)
    cps = torch.cos(ps)
    x2, y2, z2 = x * x, y * y, z * z
    tps = sps / cps
    htp = tps * 0.5
    xsm = x * cps - z * sps
    zsm = x * sps + z * cps

    # shape of the tail current sheet zs(x,y) and its derivatives
    xrc = xsm + rc
    xrc16 = xrc ** 2 + 16
    sxrc = torch.sqrt(xrc16)
    y4 = y2 * y2
    y410 = y4 + 1e4
    sy4 = sps / y410
    gsy4 = g * sy4
    zs1 = htp * (xrc - sxrc)
    dzsx = -zs1 / sxrc
    zs = zs1 - gsy4 * y4
    d2zsgy = -sy4 / y410 * 4e4 * y2 * y
    dzsy = g * d2zsgy

    # ring current
    xsm2 = xsm ** 2
    dsqt = torch.sqrt(xsm2 + a02)
    fa0 = 0.5 * (1 + xsm / dsqt)
    ddr = d0 + dd * fa0
    dfa0 = ha02 / dsqt ** 3
    zr = zsm - zs
    tr = torch.sqrt(zr ** 2 + ddr ** 2)
    rtr = 1 / tr
    ro2 = xsm2 + y2
    adrt = adr + tr
    adrt2 = adrt ** 2
    fk = 1 / (adrt2 + ro2)
    dsfc = torch.sqrt(fk)
    fc = fk ** 2 * dsfc
    facxy = 3 * adrt * fc * rtr
    xzr = xsm * zr
    yzr = y * zr
    dbxdp = facxy * xzr
    rc_y = facxy * yzr
    xzyz = xsm * dzsx + y * dzsy
    faq = zr * xzyz - ddr * dd * dfa0 * xsm
    dbzdp = fc * (2 * adrt2 - ro2) + facxy * faq
    rc_x = dbxdp * cps + dbzdp * sps
    rc_z = dbzdp * cps - dbxdp * sps

    # tail current sheet (the |gam|>=1e-6 branch; reduces exactly to the other when gam=0)
    dely2 = delt * y2
    xxd = xsm - xd
    rqd = 1 / (xxd ** 2 + xld2)
    rqds = torch.sqrt(rqd)
    h = 0.5 * (1 + xxd * rqds)
    hs = -hxld2m * rqd * rqds
    d = dt + dely2 + gam * h
    xghs = xsm * gam * hs
    adsl = -d * xghs
    d2 = d ** 2
    t = torch.sqrt(zr ** 2 + d2)
    xsmx = xsm - sx
    rdsq2 = 1 / (xsmx ** 2 + xlw2)
    rdsq = torch.sqrt(rdsq2)
    v = 0.5 * (1 - xsmx * rdsq)
    dvx = hxlw2m * rdsq * rdsq2
    om = torch.sqrt(torch.sqrt(xsm2 + 16) - xsm)
    oms = -om / (om * om + xsm) * 0.5
    rdy = 1 / (p + q * om)
    omsv = oms * v
    rdy2 = rdy ** 2
    fy = 1 / (1 + y2 * rdy2)
    w = v * fy
    yfy1 = 2 * fy * y2 * rdy2
    fypr = yfy1 * rdy
    fydy = fypr * fy
    dwx = dvx * fy + fydy * q * omsv
    ydwy = -v * yfy1 * fy
    ddy = dbldel * y
    att = at + t
    s1 = torch.sqrt(att ** 2 + ro2)
    f5 = 1 / s1
    f7 = 1 / (s1 + att)
    f1 = f5 * f7
    f3 = f5 ** 3
    f9 = att * f3
    fs = zr * xzyz - d * y * ddy + adsl
    xdwx = xsm * dwx + ydwy
    rtt = 1 / t
    wt = w * rtt
    brrz1 = wt * f1
    brrz2 = wt * f3
    dbxc1 = brrz1 * xzr
    dbxc2 = brrz2 * xzr
    t1_y = brrz1 * yzr
    t2_y = brrz2 * yzr
    wtfs = wt * fs
    dbzc1 = w * f5 + xdwx * f7 + wtfs * f1
    dbzc2 = w * f9 + xdwx * f1 + wtfs * f3
    t1_x = dbxc1 * cps + dbzc1 * sps
    t2_x = dbxc2 * cps + dbzc2 * sps
    t1_z = dbzc1 * cps - dbxc1 * sps
    t2_z = dbzc2 * cps - dbxc2 * sps

    # closure currents
    zpl = z + rt
    zmn = z - rt
    rogsm2 = x2 + y2
    spl = torch.sqrt(zpl ** 2 + rogsm2)
    smn = torch.sqrt(zmn ** 2 + rogsm2)
    xsxc = x - sxc
    rqc2 = 1 / (xsxc ** 2 + xlwc2)
    rqc = torch.sqrt(rqc2)
    fyc = 1 / (1 + y2 * rdyc2)
    wc = 0.5 * (1 - xsxc * rqc) * fyc
    dwcx = hlwc2m * rqc2 * rqc * fyc
    dwcy = drdyc2 * wc * fyc * y
    szrp = 1 / (spl + zpl)
    szrm = 1 / (smn - zmn)
    xywc = x * dwcx + y * dwcy
    wcsp = wc / spl
    wcsm = wc / smn
    fxyp = wcsp * szrp
    fxym = wcsm * szrm
    fxpl = x * fxyp
    fxmn = -x * fxym
    fypl = y * fxyp
    fymn = -y * fxym
    fzpl = wcsp + xywc * szrp
    fzmn = wcsm + xywc * szrm
    bxcl = ak3 * (fxpl + fxmn) + ak4 * (fxpl - fxmn) * sps
    bycl = ak3 * (fypl + fymn) + ak4 * (fypl - fymn) * sps
    bzcl = ak3 * (fzpl + fzmn) + ak4 * (fzpl - fzmn) * sps

    # Chapman-Ferraro + Birkeland-type terms
    ex = torch.exp(x / dx)
    ec = ex * cps
    es = ex * sps
    ecz = ec * z
    esz = es * z
    eszy2 = esz * y2
    eszz2 = esz * z2
    ecz2 = ecz * z
    esy = es * y
    sx1 = ak6 * ecz + ak7 * es + ak8 * esy * y + ak9 * esz * z
    sy1 = ak10 * ecz * y + ak11 * esy + ak12 * esy * y2 + ak13 * esy * z2
    sz1 = ak14 * ec + ak15 * ec * y2 + ak610 * ecz2 + ak711 * esz + ak812 * eszy2 + ak913 * eszz2

    tail_amp1 = ak1 + ak16 * tlt2
    tail_amp2 = ak2 + ak17 * tlt2
    bx = tail_amp1 * t1_x + tail_amp2 * t2_x + bxcl + ak5 * rc_x + sx1
    by = tail_amp1 * t1_y + tail_amp2 * t2_y + bycl + ak5 * rc_y + sy1
    bz = tail_amp1 * t1_z + tail_amp2 * t2_z + bzcl + ak5 * rc_z + sz1
    return bx, by, bz


# ----------------------------------------------------------------------------------
# Geodipole (GSM)
# ----------------------------------------------------------------------------------
def dipole(x, y, z, ps, dipmom):
    """Geodipole field in GSM, nT. dipmom = sqrt(g10^2+g11^2+h11^2) in nT."""
    x, y, z = (torch.as_tensor(v, dtype=DTYPE) for v in (x, y, z))
    ps = torch.as_tensor(ps, dtype=DTYPE)
    sps, cps = torch.sin(ps), torch.cos(ps)
    p, u, t = x ** 2, z ** 2, y ** 2
    v = 3 * z * x
    q = dipmom / torch.sqrt(p + t + u) ** 5
    bx = q * ((t + u - 2. * p) * sps - v * cps)
    by = -3. * y * q * (x * sps + z * cps)
    bz = q * ((p + t - 2. * u) * cps - v * sps)
    return bx, by, bz


# ----------------------------------------------------------------------------------
# IGRF (vectorized Schmidt recursion, identical to geopack.igrf_geo)
# ----------------------------------------------------------------------------------
class IGRF:
    """
    Vectorized IGRF internal field.  Coefficients (geopack-normalised g, h, rec) and the
    GEO->GSM rotation matrix are taken from geopack after geopack.recalc(ut), so the
    epoch handling is identical to the reference.

    truncate='geopack' reproduces geopack's distance-dependent truncation
    nm = min(13, 3 + 30 // int(r+2)) (piecewise in r, i.e. not smooth);
    truncate=None (default) keeps all degrees n <= 13 — smooth in r, recommended
    for differentiation.
    """

    def __init__(self, g, h, rec, A, nmax=13, dtype=DTYPE):
        self.g = torch.as_tensor(g, dtype=dtype)
        self.h = torch.as_tensor(h, dtype=dtype)
        self.rec = torch.as_tensor(rec, dtype=dtype)
        self.A = torch.as_tensor(A, dtype=dtype)        # gsm = A @ geo
        self.nmax = nmax
        self.dipmom = float(math.sqrt(g[1] ** 2 + g[2] ** 2 + h[2] ** 2))

    @classmethod
    def from_geopack(cls, ut):
        from geopack import geopack as gp
        ps = gp.recalc(ut)
        A = [[gp.a11, gp.a12, gp.a13], [gp.a21, gp.a22, gp.a23], [gp.a31, gp.a32, gp.a33]]
        obj = cls(gp.g.copy(), gp.h.copy(), gp.rec.copy(), A)
        obj.ps = float(ps)
        return obj

    def geo(self, r, theta, phi, truncate=None):
        """Spherical GEO components (br, btheta, bphi) in nT; r in Re, angles in rad."""
        ct, st = torch.cos(theta), torch.sin(theta)
        st_safe = torch.where(st.abs() < 1e-12, torch.full_like(st, 1e-12), st)
        k = self.nmax + 1
        if truncate == 'geopack':
            irp3 = torch.floor(r + 2)
            kpt = torch.clamp(3 + torch.floor(30.0 / irp3), max=13) + 1
        ar = 1.0 / r
        a = [ar * ar]
        for n in range(1, k):
            a.append(a[-1] * ar)
        b = [a[n] * (n + 1) for n in range(k)]
        if truncate == 'geopack':
            mask = [(n < kpt).to(r.dtype) for n in range(k)]
            a = [a[n] * mask[n] for n in range(k)]
            b = [b[n] * mask[n] for n in range(k)]
        g, hh, rec = self.g, self.h, self.rec
        br = torch.zeros_like(r * ct)
        bt = torch.zeros_like(br)
        bf = torch.zeros_like(br)
        pmm = torch.ones_like(ct)
        dmm = torch.zeros_like(ct)
        l0 = 0
        for m in range(0, k):
            if m == 0:
                cmf, smf = torch.ones_like(phi), torch.zeros_like(phi)
            else:
                cmf, smf = torch.cos(m * phi), torch.sin(m * phi)
                l0 += m + 1
            p1, d1 = pmm, dmm
            p2 = torch.zeros_like(ct)
            d2 = torch.zeros_like(ct)
            tbf = torch.zeros_like(br)
            mn = l0
            for n in range(m, k):
                w = g[mn] * cmf + hh[mn] * smf
                br = br + b[n] * w * p1
                bt = bt - a[n] * w * d1
                if m > 0:
                    tbf = tbf + a[n] * (g[mn] * smf - hh[mn] * cmf) * p1
                xk = rec[mn]
                d0 = ct * d1 - st * p1 - xk * d2
                p0 = ct * p1 - xk * p2
                d2, p2, d1 = d1, p1, d0
                p1 = p0
                mn += n + 1
            dmm = st * dmm + ct * pmm
            pmm = st * pmm
            if m > 0:
                bf = bf + m * tbf
        bf = bf / st_safe
        return br, bt, bf

    def gsm(self, x, y, z, truncate=None):
        """IGRF field in GSM (nT) at GSM position (Re)."""
        x, y, z = (torch.as_tensor(v, dtype=DTYPE) for v in (x, y, z))
        A = self.A
        xg = A[0, 0] * x + A[1, 0] * y + A[2, 0] * z
        yg = A[0, 1] * x + A[1, 1] * y + A[2, 1] * z
        zg = A[0, 2] * x + A[1, 2] * y + A[2, 2] * z
        rho2 = xg ** 2 + yg ** 2
        r = torch.sqrt(rho2 + zg ** 2)
        rho = torch.sqrt(rho2)
        theta = torch.atan2(rho, zg)
        phi = torch.atan2(yg, xg)
        br, bt, bf = self.geo(r, theta, phi, truncate)
        st, ct = torch.sin(theta), torch.cos(theta)
        sf, cf = torch.sin(phi), torch.cos(phi)
        be = br * st + bt * ct
        bxg = be * cf - bf * sf
        byg = be * sf + bf * cf
        bzg = br * ct - bt * st
        bx = A[0, 0] * bxg + A[0, 1] * byg + A[0, 2] * bzg
        by = A[1, 0] * bxg + A[1, 1] * byg + A[1, 2] * bzg
        bz = A[2, 0] * bxg + A[2, 1] * byg + A[2, 2] * bzg
        return bx, by, bz


# ----------------------------------------------------------------------------------
# Autodiff utilities: Jacobian, divergence, curl, current density
# ----------------------------------------------------------------------------------
MU0 = 4e-7 * math.pi
RE_M = 6371.2e3


def field_jacobian(field_fn, pos):
    """
    pos: (N,3) tensor.  field_fn(x,y,z) -> (bx,by,bz), each (N,).
    Returns B (N,3) and J (N,3,3) with J[:,i,j] = dB_i/dx_j (nT/Re), via 3 reverse passes
    (cheap because points are independent: the sum trick gives per-point gradients).
    """
    pos = pos.detach().requires_grad_(True)
    B = torch.stack(field_fn(pos[:, 0], pos[:, 1], pos[:, 2]), -1)
    rows = []
    for i in range(3):
        gi, = torch.autograd.grad(B[:, i].sum(), pos, retain_graph=True, create_graph=False)
        rows.append(gi)
    return B.detach(), torch.stack(rows, 1)


def div_curl(J):
    div = J[:, 0, 0] + J[:, 1, 1] + J[:, 2, 2]
    curl = torch.stack([J[:, 2, 1] - J[:, 1, 2], J[:, 0, 2] - J[:, 2, 0], J[:, 1, 0] - J[:, 0, 1]], -1)
    return div, curl


def current_density_nA_m2(curl_nT_per_Re):
    """j = curl B / mu0, converting nT/Re -> A/m^2 -> nA/m^2."""
    return curl_nT_per_Re * 1e-9 / RE_M / MU0 * 1e9


# ----------------------------------------------------------------------------------
# Differentiable, batched field-line tracing (fixed-step RK4 along unit B)
# ----------------------------------------------------------------------------------
def trace_footpoints(field_fn, start, direction=1.0, r0=1.0, rlim=60.0, ds=0.05, nsteps=4000):
    """
    Trace many field lines at once from start (N,3) (GSM, Re) until |r| <= r0.
    direction=+1 follows -B (antiparallel, i.e. toward the northern footpoint from the
    equator for a dipole-like field), matching geopack's dir convention.
    Lines that leave r > rlim are frozen and flagged.  The step crossing r0 is resolved by
    linear interpolation, so the footpoint is a smooth function of the inputs
    (differentiable w.r.t. starting point and model parameters).
    Returns foot (N,3), done mask (N,), escaped mask (N,).
    """
    p = start.clone()
    N = p.shape[0]
    done = torch.zeros(N, dtype=torch.bool)
    esc = torch.zeros(N, dtype=torch.bool)
    foot = p.clone()

    def f(q):
        b = torch.stack(field_fn(q[:, 0], q[:, 1], q[:, 2]), -1)
        return -direction * b / b.norm(dim=-1, keepdim=True)

    for _ in range(nsteps):
        active = ~(done | esc)
        if not bool(active.any()):
            break
        r = p.norm(dim=-1)
        # adaptive fixed rule (deterministic, so differentiable): shrink step near the Earth
        h = torch.clamp(0.03 * (r - r0) + 0.002, max=ds).unsqueeze(-1)
        k1 = f(p); k2 = f(p + 0.5 * h * k1); k3 = f(p + 0.5 * h * k2); k4 = f(p + h * k3)
        pn = p + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        rn = pn.norm(dim=-1)
        cross = active & (rn <= r0)
        lam = ((r - r0) / (r - rn)).clamp(0, 1).unsqueeze(-1)
        fp = p + lam * (pn - p)
        foot = torch.where(cross.unsqueeze(-1), fp, foot)
        done = done | cross
        out = active & (rn > rlim)
        esc = esc | out
        upd = (active & ~cross & ~out).unsqueeze(-1)
        p = torch.where(upd, pn, p)
    return foot, done, esc
