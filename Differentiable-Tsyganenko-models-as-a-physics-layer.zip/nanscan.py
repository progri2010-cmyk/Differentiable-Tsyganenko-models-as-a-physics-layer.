import numpy as np, torch, sys, warnings; warnings.filterwarnings('ignore')
from tsyg.t96 import t96; from tsyg.t01 import t01; from tsyg.t04 import t04
f = {'t96': t96, 't01': t01, 't04': t04}[sys.argv[1]]
par = {'t96': [3.0, -50., 3.0, -4.0]+[0.]*6, 't01': [3.0, -50., 3.0, -4.0, 1.5, 3.0]+[0.]*4, 't04': [3.0,-50.,3.0,-4.0,.8,.9,1.1,1.2,1.3,1.4]}[sys.argv[1]]
g = np.stack(np.meshgrid(np.linspace(-14.7, 14.7, 31), np.linspace(-24.3, 24.3, 21), np.linspace(-19.1, 19.1, 21)), -1).reshape(-1, 3)
g = g[np.linalg.norm(g, axis=1) > 1.5]
G = torch.tensor(g).requires_grad_(True)
B = torch.stack(f(par, 0.25, G[:,0], G[:,1], G[:,2]), 1)
gG, = torch.autograd.grad(B.pow(2).sum(), G)
bad = ~torch.isfinite(gG).all(1)
print('nonfinite field', int((~torch.isfinite(B)).sum()), 'bad grad pts', int(bad.sum()))
print(g[bad.numpy()][:10])
