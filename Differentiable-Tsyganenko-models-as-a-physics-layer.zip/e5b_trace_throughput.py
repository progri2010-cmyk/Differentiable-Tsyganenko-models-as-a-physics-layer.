import numpy as np, torch, datetime, time, json
from geopack import geopack as gp
import tsyg_torch as tt
torch.set_num_threads(2)
ut = (datetime.datetime(2015,3,17,12)-datetime.datetime(1970,1,1)).total_seconds()
ig = tt.IGRF.from_geopack(ut); PS = ig.ps; a = tt.t89_coeffs(4)
f = lambda x,y,z: tuple(u+v for u,v in zip(ig.gsm(x,y,z), tt.t89(x,y,z,PS,a)))
rng = np.random.default_rng(5); rows = []
for n in (10, 100, 1000, 4000):
    phi = rng.uniform(np.radians(120), np.radians(240), n); r = rng.uniform(3, 10, n)
    st = torch.tensor(np.stack([r*np.cos(phi), r*np.sin(phi), np.zeros(n)], 1))
    t0 = time.perf_counter(); ft, done, esc = tt.trace_footpoints(f, st, direction=-1.0, ds=0.1, nsteps=20000); t = time.perf_counter()-t0
    k = min(n, 30); t0 = time.perf_counter()
    for s in st.numpy()[:k]: gp.trace(*s, dir=-1, rlim=60, r0=1.0, parmod=4, exname='t89', inname='igrf', maxloop=3000)
    tg = (time.perf_counter()-t0)*n/k
    rows.append(dict(n_lines=n, t_torch_s=t, t_geopack_s=tg, geopack_extrapolated=n>30, done_frac=float(done.double().mean()))); print(rows[-1])
json.dump(rows, open('results_e5b.json','w'), indent=1)
