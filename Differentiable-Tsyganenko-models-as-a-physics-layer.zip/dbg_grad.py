import numpy as np, torch, warnings; warnings.filterwarnings('ignore')
from tsyg.t01 import t01
rng = np.random.default_rng(8)
P=[]
while len(P)<400:
    p=rng.uniform([-14,-10,-8],[8,10,8]); r=np.linalg.norm(p)
    if 2.5<r<12: P.append(p)
P=torch.tensor(np.array(P))
base=[3.0,-50.,3.0,-4.0,1.5,3.0]
for k in (0,1,5):
    th=torch.tensor(base, dtype=torch.float64).expand(400,-1).clone().requires_grad_(True)
    B=torch.stack(t01([th[:,j] for j in range(6)]+[0.]*4,0.25,P[:,0],P[:,1],P[:,2]),1)
    J=torch.autograd.grad(B[:,0].sum(),th)[0][:,k]
    out=[]
    for h in (1e-3,1e-4,1e-5,1e-6):
        tp=list(base); tm=list(base); tp[k]+=h; tm[k]-=h
        fd=(t01(tp,0.25,P[:,0],P[:,1],P[:,2])[0]-t01(tm,0.25,P[:,0],P[:,1],P[:,2])[0])/(2*h)
        err=(J-fd).abs()
        out.append((h, float(err.max()), float(err.median()), int(err.argmax())))
    print(k, out, 'scale', float(J.abs().max()))
    i=out[2][3]; print('   worst point', P[i].numpy(), 'AD', float(J[i]))
