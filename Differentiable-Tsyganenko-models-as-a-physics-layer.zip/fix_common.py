"""Vectorization edits shared by T01 and T04 sub-modules (identical code in both)."""
import sys
p = sys.argv[1]; s = open(p).read()
R = []
R.append(('''    if (y == 0) & (z == 0):
        phi=0.
        cphi=1.
        sphi=0.
    else:
        phi=np.arctan2(z,y)
        cphi=y/rho
        sphi=z/rho
''', '''    axis = (np._t(y) == 0) & (np._t(z) == 0)
    rho_ = np.where(axis, 1., rho)
    phi = np.where(axis, 0., np.arctan2(z, np.where(axis, 1., y)))
    cphi = np.where(axis, 1., y/rho_)
    sphi = np.where(axis, 0., z/rho_)
'''))
R.append(("""    if (xsc == 0) & (zsc == 0):
        phi=0.
    else:
        phi=np.arctan2(-zsc,xsc)  # from cartesian to cylindrical (rho,phi,y)
""", """    axis = (np._t(xsc) == 0) & (np._t(zsc) == 0)
    phi = np.where(axis, 0., np.arctan2(-zsc, np.where(axis, 1., xsc)))  # cartesian -> cylindrical
"""))
R.append(("""    if theta >= tetanm:
        tgp=np.tan(tetanp*0.5)""", """    if True:   # constants of the cone, computed unconditionally
        tgp=np.tan(tetanp*0.5)"""))
R.append(("""        if theta < tetanm:
            t=tm
            dtt=0.5*m*tm*(tg+ctg)
            dtt0=0
        elif theta < tetanp:
            tgm2m=tgm2m*tgm2
            fc=1/(tgp-tgm)
            fc1=1/(2*m+1)
            tgm2m1=tgm2m*tgm
            tg21=1+tg*tg
            t=fc*(tm*(tgp-tg)+fc1*(tm*tg-tgm2m1/tm))
            dtt=0.5*m*fc*tg21*(tm/tg*(tgp-tg)-fc1*(tm-tgm2m1/(tm*tg)))
            dtt0=0.5*fc*((tgp+tgm)*(tm*tg-fc1*(tm*tg-tgm2m1/tm))+tm*(1-tgp*tgm)-(1+tgm2)*tgm2m/tm)
        else:
            tgp2m=tgp2m*tgp2
            tgm2m=tgm2m*tgm2
            fc=1/(tgp-tgm)
            fc1=1/(2*m+1)
            t=fc*fc1*(tgp2m*tgp-tgm2m*tgm)/tm
            dtt=-t*m*0.5*(tg+ctg)
""", """        # a point stays in the same theta-region for all m, so the recurrences can be advanced
        # unconditionally and the three regions blended with where
        tgm2m=tgm2m*tgm2
        tgp2m=tgp2m*tgp2
        fc=1/(tgp-tgm)
        fc1=1/(2*m+1)
        t_a=tm
        dtt_a=0.5*m*tm*(tg+ctg)
        tgm2m1=tgm2m*tgm
        tg21=1+tg*tg
        t_b=fc*(tm*(tgp-tg)+fc1*(tm*tg-tgm2m1/tm))
        dtt_b=0.5*m*fc*tg21*(tm/tg*(tgp-tg)-fc1*(tm-tgm2m1/(tm*tg)))
        t_c=fc*fc1*(tgp2m*tgp-tgm2m*tgm)/tm
        dtt_c=-t_c*m*0.5*(tg+ctg)
        ra = theta < tetanm
        rb = ~ra & (theta < tetanp)
        t = np.where(ra, t_a, np.where(rb, t_b, t_c))
        dtt = np.where(ra, dtt_a, np.where(rb, dtt_b, dtt_c))
"""))
R.append(("            if znam < 20: znam=20\n", "            znam = np.maximum(znam, 20.)\n"))
R.append(("            if dst < dstt: dstt = dst\n", "            dstt = np.minimum(dst, dstt)\n"))
R.append(("            if dst >= -20: znam = 20.\n", "            znam = np.where(np._t(dst) >= -20, 20., znam)\n"))
for a, b in R:
    n = s.count(a)
    if n: s = s.replace(a, b)
    print(repr(a[:40]), n)
open(p, 'w').write(s)
