"""E6: the differentiable model as a physics layer in an inverse problem.
   Recover the continuous activity level s, the dipole tilt psi (and, in variant B, scale factors
   of the tail and ring-current systems) from noisy synthetic 'spacecraft' measurements of B_ext.
   Gradient-based L-BFGS (autograd) vs derivative-free Nelder-Mead; Gauss-Newton/Laplace
   uncertainty from the autodiff Jacobian compared with the Monte Carlo spread."""
import numpy as np, torch, json, time
from scipy.optimize import minimize
import tsyg_torch as tt
torch.set_num_threads(2)
rng = np.random.default_rng(6)

# --- synthetic orbit sampling: three elliptical equatorial-ish orbits (apogee 12-15 Re), 300 points
def orbits(n=300):
    P = []
    for apo, inc, argp in ((15, 10, 180), (12, 25, 150), (13, 5, 220)):
        E = np.linspace(0, 2*np.pi, n//3, endpoint=False)
        peri = 2.5; aa = (apo+peri)/2; e = (apo-peri)/(apo+peri)
        r = aa*(1-e*np.cos(E)); nu = 2*np.arctan2(np.sqrt(1+e)*np.sin(E/2), np.sqrt(1-e)*np.cos(E/2))
        th = nu + np.radians(argp)
        x, y = r*np.cos(th), r*np.sin(th)
        i = np.radians(inc); P.append(np.stack([x, y*np.cos(i), y*np.sin(i)], 1))
    return np.vstack(P)
P = torch.tensor(orbits()); X, Y, Z = P.T

def model(theta, variant):
    s, psi = theta[0], theta[1]
    a = tt.t89_coeffs(level=s)
    if variant == 'B':
        kT, kR = theta[2], theta[3]
        scale = torch.ones(30, dtype=torch.float64)
        a = a * torch.cat([torch.stack([kT, kT]), torch.ones(2, dtype=torch.float64), kR.reshape(1),
                           torch.ones(10, dtype=torch.float64), torch.stack([kT, kT]), torch.ones(13, dtype=torch.float64)])
    return torch.stack(tt.t89(X, Y, Z, psi, a), -1)

truth = {'A': torch.tensor([4.3, np.radians(12.0)], dtype=torch.float64),
         'B': torch.tensor([4.3, np.radians(12.0), 1.2, 0.8], dtype=torch.float64)}
init = {'A': [2.0, 0.0], 'B': [2.0, 0.0, 1.0, 1.0]}

def fit_lbfgs(obs, variant):
    th = torch.tensor(init[variant], dtype=torch.float64, requires_grad=True)
    opt = torch.optim.LBFGS([th], lr=1, max_iter=200, tolerance_grad=1e-12, tolerance_change=1e-15, line_search_fn='strong_wolfe')
    nfev = [0]
    def closure():
        opt.zero_grad(); nfev[0] += 1
        th.data[0].clamp_(1.0, 7.0)
        L = ((model(th, variant) - obs)**2).mean(); L.backward(); return L
    opt.step(closure)
    return th.detach(), nfev[0]

def fit_nm(obs, variant):
    f = lambda v: float(((model(torch.tensor(v, dtype=torch.float64), variant) - obs)**2).mean())
    r = minimize(f, init[variant], method='Nelder-Mead', options=dict(xatol=1e-8, fatol=1e-12, maxfev=20000))
    return torch.tensor(r.x), r.nfev

def laplace_sd(theta, variant, sigma):
    Jm = torch.autograd.functional.jacobian(lambda t: model(t, variant).reshape(-1), theta)   # (3N, p)
    C = sigma**2 * torch.linalg.inv(Jm.T @ Jm)
    return C.diag().sqrt()

res = {}
for variant in ('A', 'B'):
    B0 = model(truth[variant], variant).detach()
    for sigma in (0.0, 1.0, 2.0, 5.0, 10.0):
        ests, nfe, times, ests_nm, nfe_nm, times_nm = [], [], [], [], [], []
        trials = 1 if sigma == 0 else 40
        for k in range(trials):
            obs = B0 + sigma*torch.tensor(rng.normal(size=B0.shape))
            t0 = time.perf_counter(); th, nf = fit_lbfgs(obs, variant); times.append(time.perf_counter()-t0); ests.append(th.numpy()); nfe.append(nf)
            if k < 5:
                t0 = time.perf_counter(); thn, nfn = fit_nm(obs, variant); times_nm.append(time.perf_counter()-t0); ests_nm.append(thn.numpy()); nfe_nm.append(nfn)
        E = np.array(ests); T = truth[variant].numpy()
        conv = lambda v: v * np.array([1, 180/np.pi] + [1]*(len(v)-2))
        sd_lap = laplace_sd(truth[variant], variant, sigma).numpy() if sigma > 0 else np.zeros(len(T))
        row = dict(trials=trials, truth=conv(T).tolist(), mean_est=conv(E.mean(0)).tolist(),
                   bias=conv(E.mean(0)-T).tolist(), mc_sd=conv(E.std(0)).tolist(), laplace_sd=conv(sd_lap).tolist(),
                   rmse=conv(np.sqrt(((E-T)**2).mean(0))).tolist(),
                   lbfgs_mean_evals=float(np.mean(nfe)), lbfgs_mean_time_s=float(np.mean(times)),
                   nm_mean_evals=float(np.mean(nfe_nm)), nm_mean_time_s=float(np.mean(times_nm)),
                   nm_max_err=conv(np.abs(np.array(ests_nm)-T).max(0)).tolist())
        res[f'{variant}_sigma{sigma:g}'] = row
        print(variant, sigma, {k: (np.round(v, 4).tolist() if isinstance(v, list) else round(v, 4)) for k, v in row.items()})
res['units'] = 'theta = [level s, tilt (deg), kT, kR]'
res['n_points'] = int(P.shape[0]); res['r_range_Re'] = [float(P.norm(dim=1).min()), float(P.norm(dim=1).max())]
np.save('orbit_points.npy', P.numpy())
json.dump(res, open('results_e6.json', 'w'), indent=1)
