"""Minimal NumPy-like shim over PyTorch used by the translated T96/T01/T04 code.
All functions accept Python numbers or tensors and return float64 tensors, so the
translated model code is vectorized and differentiable."""
import math, torch
DT = torch.float64
pi = math.pi
e = math.e

def _t(x):
    return x if isinstance(x, torch.Tensor) else torch.as_tensor(x, dtype=DT)

def sqrt(x): return torch.sqrt(_t(x))
def exp(x): return torch.exp(_t(x))
def log(x): return torch.log(_t(x))
def sin(x): return torch.sin(_t(x))
def cos(x): return torch.cos(_t(x))
def tan(x): return torch.tan(_t(x))
def tanh(x): return torch.tanh(_t(x))
def arctan(x): return torch.atan(_t(x))
def arcsin(x): return torch.asin(_t(x))
def arccos(x): return torch.acos(_t(x))
def arctan2(y, x): return torch.atan2(_t(y), _t(x))
def abs(x): return torch.abs(_t(x))
def sign(x): return torch.sign(_t(x))
def where(c, a, b):
    c = c if isinstance(c, torch.Tensor) else torch.as_tensor(bool(c))
    return torch.where(c, _t(a), _t(b))
def maximum(a, b): return torch.maximum(_t(a), _t(b))
def minimum(a, b): return torch.minimum(_t(a), _t(b))

def array(v):
    """Numeric list -> constant tensor; list containing tensors -> plain list."""
    def has_tensor(o):
        if isinstance(o, torch.Tensor): return True
        if isinstance(o, (list, tuple)): return any(has_tensor(i) for i in o)
        return False
    if has_tensor(v):
        return list(v)
    return torch.tensor(v, dtype=DT)

class Slots:
    """Replacement for np.empty(shape) that is filled element by element with tensors."""
    def __init__(self, shape):
        self.shape = (shape,) if isinstance(shape, int) else tuple(shape)
        self.d = {}
    def _k(self, k):
        return k if isinstance(k, tuple) else (k,)
    def __setitem__(self, k, v): self.d[self._k(k)] = v
    def __getitem__(self, k): return self.d[self._k(k)]

def empty(shape): return Slots(shape)
zeros = empty

def dot(a, b):
    """np.dot for the patterns used in the models: Slots/list of tensors (rows) x coefficient vector."""
    if isinstance(a, Slots):
        if len(a.shape) == 2:
            n0, n1 = a.shape
            return [sum(a[i, j] * b[j] for j in range(n1)) for i in range(n0)]
        return sum(a[j] * b[j] for j in range(a.shape[0]))
    if isinstance(b, Slots):
        return sum(a[j] * b[j] for j in range(b.shape[0]))
    if isinstance(a, (list, tuple)) and not isinstance(b, (list, tuple, torch.Tensor)) or \
       (isinstance(a, (list, tuple)) and isinstance(b, torch.Tensor) and b.dim() == 0):
        return [ai * b for ai in a]
    return torch.matmul(_t(a), _t(b))

# --- differentiable Bessel functions J0, J1.
# torch.special.bessel_j0/j1 are only accurate to ~4e-7 and have no backward, so we use the
# integral representation J_n(x) = (1/2pi) int_0^{2pi} cos(n t - x sin t) dt evaluated with the
# trapezoidal rule, which converges geometrically for periodic integrands (error ~ J_M(x)):
# with M = 160 nodes it is at round-off level for |x| < ~100. Autograd works through it directly.
_M = 160
_tau = None
def _nodes():
    global _tau
    if _tau is None:
        t = torch.arange(_M, dtype=DT) * (2 * math.pi / _M)
        _tau = (torch.sin(t),)
    return _tau[0]

def j0(x):
    x = _t(x); st = _nodes()
    return torch.cos(x.unsqueeze(-1) * st).mean(-1)

def j1(x):
    x = _t(x); st = _nodes()
    return (torch.sin(x.unsqueeze(-1) * st) * st).mean(-1)

class _Special:
    j0 = staticmethod(j0); j1 = staticmethod(j1)
special = _Special()

# --- helpers for data-dependent branches: evaluate a branch only on the points where it applies
def sub(v, idx, n):
    if isinstance(v, torch.Tensor) and v.dim() == 1 and v.shape[0] == n:
        return v[idx]
    return v

def scatter(idx, vals, n, like=None):
    out = torch.zeros(n, dtype=DT)
    v = _t(vals)
    if v.dim() == 0: v = v.expand(idx.shape[0])
    return out.index_put((idx,), v)

def branch(mask, fn, *args):
    """Evaluate fn(*args) on the subset where mask is True (1-D mask of length n) and scatter
    each output back into zero-filled length-n tensors. Differentiable; avoids NaN from
    branches evaluated outside their domain."""
    mask = _t(mask)
    n = mask.shape[0]
    idx = torch.nonzero(mask, as_tuple=True)[0]
    if idx.numel() == 0:
        return None
    outs = fn(*[sub(a, idx, n) for a in args])
    return [scatter(idx, o, n) for o in outs]

def flat_broadcast(*args):
    """Broadcast all tensor inputs to a common shape and flatten to 1-D."""
    ts = torch.broadcast_tensors(*[_t(a) for a in args])
    shape = ts[0].shape
    return shape, [t.reshape(-1) for t in ts]

def zeros_t(n): return torch.zeros(n, dtype=DT)

def combine(n, *outs):
    """Sum the scattered outputs of disjoint branches (None = branch had no points)."""
    res = None
    for o in outs:
        if o is None: continue
        res = list(o) if res is None else [a + b for a, b in zip(res, o)]
    if res is None:
        return [torch.zeros(n, dtype=DT)] * 3
    return res

def safe_sqrt(a):
    """sqrt with a finite (zero) gradient at a == 0, e.g. on symmetry axes."""
    a = _t(a)
    pos = a > 0
    return torch.where(pos, torch.sqrt(torch.where(pos, a, torch.ones_like(a))), torch.zeros_like(a))
