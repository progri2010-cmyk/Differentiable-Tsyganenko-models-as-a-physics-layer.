"""
tsyg — vectorized, differentiable PyTorch versions of the Tsyganenko T96, T01 and T04 (TS05)
external magnetospheric field models.

The code is a line-by-line translation of the Python `geopack` package (S. Tian), itself a port of
N. A. Tsyganenko's FORTRAN.  Every data-dependent branch of the scalar code (magnetopause regions,
Birkeland-current zones, coordinate singularities, clamps) is replaced by a vectorized equivalent
(torch.where, or evaluation on the subset of points where a branch applies), so that

    bx, by, bz = t96(parmod, ps, x, y, z)

accepts tensors of any broadcastable shape for x, y, z, ps and each element of parmod, and is
differentiable with respect to all of them.  Results agree with geopack to round-off (T96) or to
the intrinsic round-off sensitivity of the reference itself (T01/T04, whose ring-current module
uses internal finite differences).

parmod (10 values):
  T96: Pdyn [nPa], Dst [nT], By_IMF, Bz_IMF [nT] (rest unused)
  T01: Pdyn, Dst, By, Bz, G1, G2
  T04: Pdyn, Dst, By, Bz, W1..W6
The T89c model, the dipole and IGRF are in ../tsyg_torch.py.
"""
from .t96 import t96
from .t01 import t01
from .t04 import t04
