"""Convert ppigrf's IGRF14.shc into the igrfXXcoeffs.txt layout geopack expects (offline)."""
import sys, os
src, dst = sys.argv[1], sys.argv[2]
lines = [l for l in open(src) if not l.startswith('#')]
years = [float(v) for v in lines[1].split()]
rows = []
for l in lines[2:]:
    c = l.split()
    if not c: continue
    n, m = int(c[0]), int(c[1]); v = [float(x) for x in c[2:]]
    gh = 'g' if m >= 0 else 'h'
    vals = v[:-1] + [(v[-1]-v[-2])/(years[-1]-years[-2])]   # last column = secular variation
    rows.append((gh, n, abs(m), vals))
hdr = 'g/h n m ' + ' '.join(f'{y:.1f}' for y in years[:-1]) + f' {int(years[-2])}-{str(int(years[-1]))[2:]}'
with open(dst, 'w') as f:
    f.write('# IGRF14 converted from ppigrf IGRF14.shc\n# \nc/s deg ord ' + 'IGRF '*len(years) + '\n')
    f.write(hdr + '\n')
    for gh, n, m, vals in rows:
        f.write(f'{gh} {n} {m} ' + ' '.join(f'{x:.3f}' for x in vals) + '\n')
print('wrote', dst, len(rows), 'rows')
