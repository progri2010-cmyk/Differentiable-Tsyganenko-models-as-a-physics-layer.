"""E2: correctness of autodiff derivatives (vs geopack analytic der, and vs finite differences);
   E3: physics diagnostics div B and curl B -> current density."""
import numpy as np, torch, json
from geopack.t89 import extern
import tsyg_torch as tt
rng = np.random.default_rng(2)
res = {}
N = 3000
x = rng.uniform(-50, 10, N); y = rng.uniform(-20, 20, N); z = rng.uniform(-15, 15, N)
ok = np.sqrt(x*x+y*y+z*z) > 2; x, y, z = x[ok], y[ok], z[ok]; N = len(x)
ps = rng.uniform(np.radians(-30), np.radians(30), N)
X, Y, Z, PS = (torch.tensor(v) for v in (x, y, z, ps))

# ---- (a) dB/da via autograd vs geopack's analytic derivative matrix der (linear params 0..16)
for iopt in (2, 5):
    a0 = tt.t89_coeffs(iopt)
    A = a0.expand(N, 30).clone().requires_grad_(True)
    B = torch.stack(tt.t89(X, Y, Z, PS, A), -1)
    Jp = torch.stack([torch.autograd.grad(B[:, i].sum(), A, retain_graph=True)[0] for i in range(3)], 1)  # (N,3,30)
    der = np.array([extern(1, a0.numpy(), np.array([x[k], y[k], z[k], ps[k]]))[3] for k in range(N)])  # (N,3,30)
    lin = slice(0, 17)
    d = np.abs(Jp.numpy()[:, :, lin] - der[:, :, lin]); s = np.abs(der[:, :, lin]).max()
    res[f'dB_da_linear_vs_der_iopt{iopt}'] = dict(max_abs=float(d.max()), max_rel_to_maxder=float(d.max()/s))
    # linearity check: B == sum_k a_k * der_k for linear parameters + nothing else? (sx/sz cf terms use derived ak610.. so only check autograd vs der)
    # ---- (b) all 30 params vs central FD
    Jp_np = Jp.numpy(); fd_err = []
    for k in range(30):
        hk = 1e-6 * max(1.0, abs(float(a0[k])))
        ap, am = a0.clone(), a0.clone(); ap[k] += hk; am[k] -= hk
        Bp = torch.stack(tt.t89(X, Y, Z, PS, ap), -1); Bm = torch.stack(tt.t89(X, Y, Z, PS, am), -1)
        fd = ((Bp - Bm) / (2 * hk)).numpy()
        sc = np.abs(fd).max() + 1e-30
        fd_err.append(float(np.abs(fd - Jp_np[:, :, k]).max() / sc))
    res[f'dB_da_all30_vs_FD_iopt{iopt}'] = dict(max_rel=max(fd_err), worst_param=int(np.argmax(fd_err)), per_param=fd_err)
    print(iopt, res[f'dB_da_linear_vs_der_iopt{iopt}'], 'FD max rel', max(fd_err))

# ---- (c) spatial Jacobian, tilt and activity-level derivatives vs FD
a0 = tt.t89_coeffs(4)
pos = torch.stack([X, Y, Z], 1)
f = lambda xx, yy, zz: tt.t89(xx, yy, zz, PS, a0)
B, J = tt.field_jacobian(f, pos)
h = 1e-5; Jfd = torch.zeros_like(J)
for j in range(3):
    e = torch.zeros(3, dtype=torch.float64); e[j] = h
    pp, pm = pos + e, pos - e
    Jfd[:, :, j] = (torch.stack(f(*pp.T), -1) - torch.stack(f(*pm.T), -1)) / (2 * h)
res['spatial_jacobian_vs_FD'] = dict(max_abs_nT_per_Re=float((J - Jfd).abs().max()), max_rel=float(((J - Jfd).abs().max() / J.abs().max())))
psr = PS.clone().requires_grad_(True)
Bt = torch.stack(tt.t89(X, Y, Z, psr, a0), -1)
gps = torch.stack([torch.autograd.grad(Bt[:, i].sum(), psr, retain_graph=True)[0] for i in range(3)], 1)
hp = 1e-6
fdps = (torch.stack(tt.t89(X, Y, Z, PS + hp, a0), -1) - torch.stack(tt.t89(X, Y, Z, PS - hp, a0), -1)) / (2 * hp)
res['dB_dtilt_vs_FD'] = dict(max_rel=float((gps - fdps).abs().max() / fdps.abs().max()))
lv = torch.tensor(3.4, dtype=torch.float64, requires_grad=True)
Bl = torch.stack(tt.t89(X, Y, Z, PS, tt.t89_coeffs(level=lv)), -1)
gl = torch.autograd.grad(Bl.sum(), lv)[0]
fdl = (torch.stack(tt.t89(X, Y, Z, PS, tt.t89_coeffs(level=3.4 + 1e-6)), -1).sum() - torch.stack(tt.t89(X, Y, Z, PS, tt.t89_coeffs(level=3.4 - 1e-6)), -1).sum()) / 2e-6
res['dB_dlevel_vs_FD'] = dict(rel=float(abs(gl - fdl) / abs(fdl)))
# second derivatives (Hessian of |B|^2 wrt tilt) — demonstrates higher-order AD
psr2 = torch.tensor(0.3, dtype=torch.float64, requires_grad=True)
Bq = torch.stack(tt.t89(X[:50], Y[:50], Z[:50], psr2, a0), -1)
g1 = torch.autograd.grad((Bq ** 2).sum(), psr2, create_graph=True)[0]
g2 = torch.autograd.grad(g1, psr2)[0]
E = lambda s: float((torch.stack(tt.t89(X[:50], Y[:50], Z[:50], s, a0), -1) ** 2).sum())
fd2 = (E(0.3 + 1e-4) - 2 * E(0.3) + E(0.3 - 1e-4)) / 1e-8
res['d2_B2_dtilt2_vs_FD'] = dict(rel=float(abs(g2 - fd2) / abs(fd2)))
print({k: v for k, v in res.items() if 'all30' not in k})

# ---- (E3) div B and current density over the random points
div, curl = tt.div_curl(J)
jn = J.flatten(1).norm(dim=1)
res['divB'] = dict(max_abs_nT_per_Re=float(div.abs().max()), max_rel_to_gradnorm=float((div.abs() / jn).max()),
                   median_curl_nT_per_Re=float(curl.norm(dim=1).median()))
print('divB', res['divB'])
json.dump(res, open('results_e2.json', 'w'), indent=1)
