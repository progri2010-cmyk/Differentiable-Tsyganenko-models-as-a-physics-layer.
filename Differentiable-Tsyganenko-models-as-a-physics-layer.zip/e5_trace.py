"""E5: batched differentiable field-line tracing (IGRF + T89c) vs geopack.trace, and
   gradients of footpoint latitude w.r.t. activity level and tilt (autograd vs FD)."""
import numpy as np, torch, datetime, json, time
from geopack import geopack as gp
import tsyg_torch as tt
torch.set_num_threads(2)
ut = (datetime.datetime(2015, 3, 17, 12) - datetime.datetime(1970, 1, 1)).total_seconds()
ig = tt.IGRF.from_geopack(ut); PS = ig.ps
res = {'epoch': '2015-03-17T12:00Z', 'tilt_deg': float(np.degrees(PS))}
xs = np.array([-3., -4., -5., -6., -7., -8., -9., -10., -12.])
starts = np.array([[x, yy, 0.] for x in xs for yy in (-3., 0., 3.)])
def lat(p): return np.degrees(np.arcsin(p[..., 2] / np.linalg.norm(p, axis=-1)))
out = {}
for iopt in (1, 4, 7):
    a = tt.t89_coeffs(iopt)
    for d in (1.0, -1.0):
        t0 = time.perf_counter()
        ref = np.array([gp.trace(*s, dir=d, rlim=60, r0=1.0, parmod=iopt, exname='t89', inname='igrf', maxloop=3000)[:3] for s in starts])
        tg = time.perf_counter() - t0
        f_tr = lambda x, y, z: tuple(u + v for u, v in zip(ig.gsm(x, y, z, truncate='geopack'), tt.t89(x, y, z, PS, a)))
        t0 = time.perf_counter()
        foot, done, esc = tt.trace_footpoints(f_tr, torch.tensor(starts), direction=d, ds=0.1, nsteps=20000)
        tt_ = time.perf_counter() - t0
        fine, _, _ = tt.trace_footpoints(f_tr, torch.tensor(starts), direction=d, ds=0.02, nsteps=60000)
        foot, fine = foot.numpy(), fine.numpy()
        out[f'iopt{iopt}_dir{int(d)}'] = dict(
            n=len(starts), all_done=bool(done.all()),
            max_dist_vs_geopack_km=float(np.linalg.norm(foot - ref, axis=1).max() * 6371.2),
            max_dist_vs_fine_km=float(np.linalg.norm(foot - fine, axis=1).max() * 6371.2),
            max_dist_geopack_vs_fine_km=float(np.linalg.norm(ref - fine, axis=1).max() * 6371.2),
            max_dlat_vs_geopack_deg=float(np.abs(lat(foot) - lat(ref)).max()),
            t_geopack_s=tg, t_torch_batched_s=tt_)
        print(iopt, d, out[f'iopt{iopt}_dir{int(d)}'])
res['trace_vs_geopack'] = out

# gradients of northern-footpoint latitude w.r.t. continuous level s and tilt psi
st = torch.tensor([[-6., 0., 0.], [-8., 0., 0.], [-10., 0., 0.]])
def foot_lat(level, psi):
    a = tt.t89_coeffs(level=level)
    f = lambda x, y, z: tuple(u + v for u, v in zip(tt.dipole(x, y, z, psi, ig.dipmom), tt.t89(x, y, z, psi, a)))
    ft, done, _ = tt.trace_footpoints(f, st, direction=-1.0, ds=0.05, nsteps=40000)
    return torch.rad2deg(torch.asin(ft[:, 2] / ft.norm(dim=1)))
s0 = torch.tensor(3.5, dtype=torch.float64, requires_grad=True)
p0 = torch.tensor(0.2, dtype=torch.float64, requires_grad=True)
t0 = time.perf_counter()
L = foot_lat(s0, p0)
G = torch.stack([torch.stack(torch.autograd.grad(L[i], (s0, p0), retain_graph=True)) for i in range(3)])
tg = time.perf_counter() - t0
hs, hp = 1e-4, 1e-5
with torch.no_grad():
    fds = (foot_lat(3.5 + hs, 0.2) - foot_lat(3.5 - hs, 0.2)) / (2 * hs)
    fdp = (foot_lat(3.5, 0.2 + hp) - foot_lat(3.5, 0.2 - hp)) / (2 * hp)
res['footpoint_gradients'] = dict(start_x=[-6, -8, -10], lat_deg=L.tolist(),
    dlat_dlevel_AD=G[:, 0].tolist(), dlat_dlevel_FD=fds.tolist(),
    dlat_dtilt_AD=G[:, 1].tolist(), dlat_dtilt_FD=fdp.tolist(),
    max_rel_level=float(((G[:, 0] - fds).abs() / fds.abs()).max()),
    max_rel_tilt=float(((G[:, 1] - fdp).abs() / fdp.abs()).max()), t_forward_backward_s=tg)
print(res['footpoint_gradients'])
json.dump(res, open('results_e5.json', 'w'), indent=1)
