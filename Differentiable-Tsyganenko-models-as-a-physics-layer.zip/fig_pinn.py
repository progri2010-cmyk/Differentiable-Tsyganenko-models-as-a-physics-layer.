"""Figure for E10: reconstruction error of the five variants (mean over seeds) and error maps."""
import json, glob, numpy as np, torch, matplotlib, warnings, importlib.util, sys
matplotlib.use('Agg'); warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': '#52514e', 'axes.spines.top': False, 'axes.spines.right': False})
files = sorted(glob.glob('results_e10_s*_sig2.json')); R = [json.load(open(f)) for f in files]
keys = ['M0_T96_true_drivers', 'M1_T96_fit', 'M2_NN_only', 'M3_hybrid_frozen', 'M4_hybrid_joint']
labels = ['M0\nT96, drejtuesit\ne vërtetë', 'M1\nT96, drejtuesit\ne përshtatur', 'M2\nvetëm rrjet\n(∇×A)', 'M3\nhibrid,\nprior i ngrirë', 'M4\nhibrid,\ntrajnim i përbashkët']
C = {'rmse_near': '#2a78d6', 'rmse_all': '#1baf7a', 'rmse_far': '#eb6834'}
names = {'rmse_near': 'afër orbitave (< 1,5 Re)', 'rmse_all': 'i gjithë vëllimi', 'rmse_far': 'larg orbitave (> 3 Re)'}
fig, ax = plt.subplots(1, 2, figsize=(11, 3.9), constrained_layout=True, gridspec_kw=dict(width_ratios=[1.25, 1]))
w = 0.26
for j, m in enumerate(('rmse_near', 'rmse_all', 'rmse_far')):
    v = np.array([[r[k][m] for k in keys] for r in R])
    ax[0].bar(np.arange(5) + (j-1)*w, v.mean(0), w*0.92, yerr=v.std(0) if len(R) > 1 else None, color=C[m], label=names[m],
              error_kw=dict(lw=1, capsize=2, ecolor='#52514e'))
ax[0].set_xticks(np.arange(5)); ax[0].set_xticklabels(labels, fontsize=7.5)
ax[0].set_ylabel('RMSE e |ΔB| (nT)'); ax[0].legend(frameon=False, fontsize=8)
ax[0].set_title(f'(a) Gabimi kundrejt fushës së vërtetë (T04 stuhi), {len(R)} fara, σ = 2 nT', fontsize=9)
ax[0].grid(axis='y', alpha=.25, lw=.5)

# error-reduction map: |B_M1 - B_true| - |B_M4 - B_true| in the plane z = 0, seed 0
spec = importlib.util.spec_from_file_location('e10', 'e10_pinn.py')
src = open('e10_pinn.py').read()
head = src[:src.index("res = dict(")]
ns = {}; sys.argv = ['x', '0', '2']; exec(compile(head, 'e10_head', 'exec'), ns)
st = torch.load('pinn_models_s0_sig2.pt')
net4 = ns['Net'](); net4.load_state_dict(st['net4'])
xs, ys = np.meshgrid(np.linspace(-14, 7, 106), np.linspace(-12, 12, 121))
P = np.stack([xs.ravel(), ys.ravel(), np.zeros(xs.size)], 1); m = ns['in_region'](P)
Pt = ns['T'](P[m]); Btrue = ns['truth'](P[m]).detach()
B1 = torch.cat([ns['t96f'](st['th1'], Pt[i:i+3000]).detach() for i in range(0, len(Pt), 3000)])
B4 = torch.cat([ns['t96f'](st['th4'], Pt[i:i+3000]).detach() for i in range(0, len(Pt), 3000)]) + \
     torch.cat([ns['curlA'](net4, Pt[i:i+3000], False).detach() for i in range(0, len(Pt), 3000)])
d = np.full(xs.size, np.nan); d[m] = ((B1 - Btrue).norm(dim=1) - (B4 - Btrue).norm(dim=1)).numpy()
from matplotlib.colors import TwoSlopeNorm
im = ax[1].pcolormesh(xs, ys, d.reshape(xs.shape), cmap='RdBu_r', norm=TwoSlopeNorm(0, -15, 15), shading='auto', rasterized=True)
D = np.load('pinn_data_s0.npy'); near_eq = np.abs(D[:, 2]) < 1.5
ax[1].plot(D[near_eq, 0], D[near_eq, 1], '.', ms=1.5, color='#0b0b0b', label='matjet me |z| < 1,5 Re')
ax[1].add_patch(plt.Circle((0, 0), 1, color='#52514e')); ax[1].set_aspect('equal')
ax[1].set_xlabel('X$_{GSM}$ (Re)'); ax[1].set_ylabel('Y$_{GSM}$ (Re)')
ax[1].set_title('(b) Përmirësimi M4 ndaj M1 në rrafshin z = 0 (fara 0)', fontsize=9)
cb = fig.colorbar(im, ax=ax[1], shrink=0.9, extend='both'); cb.set_label('|ΔB|$_{M1}$ − |ΔB|$_{M4}$ (nT)')
ax[1].legend(frameon=False, fontsize=7, loc='lower left')
fig.savefig('fig_pinn.png', dpi=170); print('ok', files)
