"""Compare the translated torch model with geopack on random points / parameters."""
import sys, numpy as np, torch, importlib, traceback, warnings
warnings.filterwarnings('ignore')
name = sys.argv[1]; N = int(sys.argv[2]) if len(sys.argv) > 2 else 300
ref = getattr(importlib.import_module(f'geopack.{name}'), name)
mod = importlib.import_module(f'tsyg.{name}'); fn = getattr(mod, name)
rng = np.random.default_rng(0)
xmin = -60 if name == 't96' else -15
P = []
while len(P) < N:
    p = rng.uniform([xmin, -25, -20], [15, 25, 20]); 
    if np.linalg.norm(p) > 1.5: P.append(p)
P = np.array(P)
ps = rng.uniform(-0.6, 0.6, N)
pd = rng.uniform(0.5, 10, N); dst = rng.uniform(-150, 20, N); by = rng.uniform(-10, 10, N); bz = rng.uniform(-10, 10, N)
if name == 't96': par = np.stack([pd, dst, by, bz] + [np.zeros(N)]*6, 1)
elif name == 't01': par = np.stack([pd, dst, by, bz, rng.uniform(0, 2, N), rng.uniform(0, 4, N)] + [np.zeros(N)]*4, 1)
else: par = np.stack([pd, dst, by, bz] + [rng.uniform(0, 2, N) for _ in range(6)], 1)
R = np.array([ref(par[i], ps[i], *P[i]) for i in range(N)])
T = lambda v: torch.tensor(v)
try:
    out = fn([T(par[:, k]) for k in range(10)], T(ps), T(P[:, 0]), T(P[:, 1]), T(P[:, 2]))
    O = torch.stack([torch.as_tensor(o).expand(N) for o in out], 1).numpy()
except Exception:
    traceback.print_exc(limit=-3); sys.exit(1)
err = np.linalg.norm(O - R, axis=1); mag = np.linalg.norm(R, axis=1)
i = err.argmax()
print(f'{name}: N={N} max_abs={err.max():.3e} nT  max_rel={(err/np.maximum(mag,1e-9)).max():.3e}  worst at p={P[i]}, par={par[i,:6]}, ref={R[i]}, got={O[i]}')
