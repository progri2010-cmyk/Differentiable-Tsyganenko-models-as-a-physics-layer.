"""E7: T96, T01, T04 — pointwise agreement with geopack, intrinsic round-off sensitivity of the
reference itself, autodiff vs finite differences, NaN-free gradients across all regions, timing."""
import numpy as np, torch, json, time, importlib, warnings, sys
warnings.filterwarnings('ignore'); torch.set_num_threads(2)
from tsyg.t96 import t96; from tsyg.t01 import t01; from tsyg.t04 import t04
from geopack import t96 as R96, t01 as R01, t04 as R04
REF = {'t96': R96.t96, 't01': R01.t01, 't04': R04.t04}; MOD = {'t96': t96, 't01': t01, 't04': t04}
rng = np.random.default_rng(7)
N = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
res = {}

def sample(name, n):
    xmin = -60 if name == 't96' else -15
    P = []
    while len(P) < n:
        p = rng.uniform([xmin, -25, -20], [15, 25, 20])
        if np.linalg.norm(p) > 1.5: P.append(p)
    P = np.array(P); ps = rng.uniform(-0.6, 0.6, n)
    pd = rng.uniform(0.5, 10, n); dst = rng.uniform(-150, 20, n); by = rng.uniform(-10, 10, n); bz = rng.uniform(-10, 10, n)
    if name == 't96': par = np.stack([pd, dst, by, bz] + [np.zeros(n)]*6, 1)
    elif name == 't01': par = np.stack([pd, dst, by, bz, rng.uniform(0, 3, n), rng.uniform(0, 6, n)] + [np.zeros(n)]*4, 1)
    else: par = np.stack([pd, dst, by, bz] + [rng.uniform(0, 3, n) for _ in range(6)], 1)
    return P, ps, par

def run(name, P, ps, par, req=False):
    T = lambda v: torch.tensor(v)
    return MOD[name]([T(par[:, k]) for k in range(10)], T(ps), T(P[:, 0]), T(P[:, 1]), T(P[:, 2]))

for name in ('t96', 't01', 't04'):
    P, ps, par = sample(name, N)
    t0 = time.perf_counter(); Rf = np.array([REF[name](par[i], ps[i], *P[i]) for i in range(N)]); tref = time.perf_counter() - t0
    # intrinsic sensitivity: the reference evaluated at positions perturbed by ~4 ulp
    Pp = P * (1 + 4e-16 * rng.choice([-1, 1], P.shape))
    Rp = np.array([REF[name](par[i], ps[i], *Pp[i]) for i in range(min(N, 1000))])
    t0 = time.perf_counter(); O = torch.stack(run(name, P, ps, par), 1).numpy(); tt_ = time.perf_counter() - t0
    e = np.linalg.norm(O - Rf, axis=1); m = np.linalg.norm(Rf, axis=1)
    es = np.linalg.norm(Rp - Rf[:len(Rp)], axis=1)
    res[name] = dict(N=N, max_abs_nT=float(e.max()), p99_abs_nT=float(np.quantile(e, .99)), median_abs_nT=float(np.median(e)),
                     max_rel=float((e / m).max()), ref_self_sensitivity_max_abs_nT=float(es.max()),
                     ref_self_sensitivity_p99_nT=float(np.quantile(es, .99)),
                     t_geopack_s=tref, t_torch_s=tt_, speedup=tref / tt_)
    print(name, res[name], flush=True)
json.dump(res, open('results_e7_accuracy.json', 'w'), indent=1)
