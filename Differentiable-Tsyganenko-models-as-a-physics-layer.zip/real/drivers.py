"""
Solar-wind drivers for T96 / T01 / T04 from the OMNI HRO 1-min file, and merge with the THEMIS-A
1-min dataset.

  Pdyn  : OMNI flow pressure; where flagged, recomputed as 2e-6 n V^2 (OMNI convention)
  Dst   : SYM-H
  By, Bz: IMF GSM
  G1, G2: T01 driving indices, 1-hour trailing averages (Tsyganenko 2002b)
          G1 = <V h(B_perp) sin^3(theta/2)>, h(b) = (b/40)^2 / (1 + b/40),  G2 = <a V B_s>, a = 0.005
  W1..W6: TS05 driving indices, computed exactly as in Tsyganenko's Prepare_input_4.f
          (5-min averages, exponents and decay rates A(45..68) of the TS05 parameter file),
          integrated from the start of the series (9 May 2024 00:00 UT, quiet conditions).
Short gaps (<= 3 h) are filled by linear interpolation, as in Tsyganenko's preprocessing.
"""
import cdflib, numpy as np, datetime as dt

OMNI = '/home/claude/rawdata/omni/72776615-omni_hro2_1min_20240501_v01.cdf'
# TS05 constants (Parameters.par, A(45)..A(68)); decay rates in 1/hour
RATE = np.array([0.383403, 0.648176, 0.0318752, 0.581168, 1.15070, 0.843004])
EXPS = np.array([[0.394732, 0.846509, 0.916555], [0.550920, 0.180725, 0.898772],
                 [0.387365, 2.26596, 1.29123], [0.436819, 1.28211, 1.33199],
                 [0.405553, 1.62290, 0.699074], [1.26131, 2.42297, 0.537116]])   # (lambda_N, beta_V, gamma_Bs)


def load_omni(t0, t1):
    c = cdflib.CDF(OMNI)
    ep = cdflib.cdfepoch.unixtime(c.varget('Epoch'))
    m = (ep >= t0) & (ep <= t1)
    out = {'t': np.asarray(ep)[m]}
    fills = {'BY_GSM': 9999.99, 'BZ_GSM': 9999.99, 'flow_speed': 99999.9, 'proton_density': 999.99,
             'Pressure': 99.99, 'SYM_H': 99999}
    for v, fv in fills.items():
        d = c.varget(v)[m].astype(float)
        d[np.abs(d - fv) < 1e-3 * abs(fv)] = np.nan
        d[np.abs(d) >= 0.99 * fv] = np.nan
        out[v] = d
    # fill gaps <= 3 h linearly
    for v in fills:
        d = out[v]; ok = np.isfinite(d)
        if ok.sum() < 2: continue
        filled = np.interp(out['t'], out['t'][ok], d[ok])
        # mark long gaps
        gapid = np.cumsum(ok)
        bad = ~ok
        if bad.any():
            starts = np.where(bad & ~np.roll(bad, 1))[0]; ends = np.where(bad & ~np.roll(bad, -1))[0]
            for s, e in zip(starts, ends):
                if (e - s + 1) > 180: filled[s:e + 1] = np.nan
        out[v + '_filled_frac'] = float(bad.mean())
        out[v] = filled
    p_re = 2e-6 * out['proton_density'] * out['flow_speed'] ** 2
    out['Pdyn'] = np.where(np.isfinite(out['Pressure']), out['Pressure'], p_re)
    out['Pdyn_recomputed'] = p_re
    return out


def g_indices(o):
    V, By, Bz = o['flow_speed'], o['BY_GSM'], o['BZ_GSM']
    bperp = np.hypot(By, Bz); theta = np.arctan2(By, Bz); theta = np.where(theta < 0, theta + 2 * np.pi, theta)
    h = (bperp / 40) ** 2 / (1 + bperp / 40)
    g1i = V * h * np.sin(theta / 2) ** 3
    g2i = 0.005 * V * np.clip(-Bz, 0, None)
    k = np.ones(60) / 60
    G1 = np.convolve(g1i, k, mode='full')[:len(V)]; G2 = np.convolve(g2i, k, mode='full')[:len(V)]
    n = np.minimum(np.arange(1, len(V) + 1), 60); G1 *= 60 / n; G2 *= 60 / n
    return G1, G2


def w_indices(o):
    """TS05 W1..W6 on the 1-min grid, from 5-min averages, following Prepare_input_4.f."""
    t = o['t']; n5 = len(t) // 5
    def avg5(x): return np.nanmean(x[:n5 * 5].reshape(n5, 5), 1)
    V5, N5, Bz5 = avg5(o['flow_speed']), avg5(o['proton_density']), avg5(o['BZ_GSM'])
    Vn, Nn, Bsn = V5 / 400., N5 * 1.16 / 5., np.clip(-Bz5 / 5., 0, None)
    W = np.zeros((n5, 6))
    for i in range(6):
        lam, beta, gam = EXPS[i]
        fac = Nn ** lam * Vn ** beta * np.where(Bsn > 0, Bsn ** gam, 0.)
        dtm = RATE[i] / 60.                         # 1/min
        decay = np.exp(-5 * dtm)                    # per 5-min step
        acc = 0.
        for k in range(n5):                         # recursive form of sum_k fac_k exp(-tau dt)
            acc = acc * decay + (fac[k] if np.isfinite(fac[k]) else 0.)
            W[k, i] = acc * dtm * 5.
    # back to 1-min grid (value of the 5-min block that contains each minute)
    W1 = np.repeat(W, 5, axis=0)
    if len(W1) < len(t): W1 = np.vstack([W1, np.repeat(W1[-1:], len(t) - len(W1), 0)])
    return W1


if __name__ == '__main__':
    t0 = dt.datetime(2024, 5, 9, tzinfo=dt.UTC).timestamp(); t1 = dt.datetime(2024, 5, 15, tzinfo=dt.UTC).timestamp()
    o = load_omni(t0, t1)
    G1, G2 = g_indices(o); W = w_indices(o)
    D = np.genfromtxt('tha_1min.csv', delimiter=',', names=True)
    ii = np.searchsorted(o['t'], D['t'])
    ok = (ii < len(o['t'])) & (np.abs(o['t'][np.clip(ii, 0, len(o['t']) - 1)] - D['t']) < 1)
    ii = np.clip(ii, 0, len(o['t']) - 1)
    cols = {n: D[n] for n in D.dtype.names}
    for k, v in (('pdyn', o['Pdyn']), ('symh', o['SYM_H']), ('imf_by', o['BY_GSM']), ('imf_bz', o['BZ_GSM']),
                 ('vsw', o['flow_speed']), ('nsw', o['proton_density']), ('g1', G1), ('g2', G2)):
        cols[k] = np.where(ok, v[ii], np.nan)
    for j in range(6): cols[f'w{j+1}'] = np.where(ok, W[ii, j], np.nan)
    names = list(cols)
    np.savetxt('tha_1min_drivers.csv', np.column_stack([cols[n] for n in names]), delimiter=',', header=','.join(names), comments='', fmt='%.6f')
    print('OMNI gap fractions:', {k[:-12]: round(v, 3) for k, v in o.items() if k.endswith('_filled_frac')})
    for k in ('Pdyn', 'SYM_H', 'BZ_GSM', 'BY_GSM', 'flow_speed', 'proton_density'):
        x = o[k]; print(f'{k}: min {np.nanmin(x):.1f} max {np.nanmax(x):.1f}')
    print('Pressure flagged but recomputable:', int((~np.isfinite(o['Pressure']) & np.isfinite(o['Pdyn_recomputed'])).sum()))
    print('G1 max %.1f G2 max %.1f' % (np.nanmax(G1), np.nanmax(G2)), 'W max', np.nanmax(W, 0).round(2))
    print('merged minutes', int(ok.sum()), 'of', len(D))
