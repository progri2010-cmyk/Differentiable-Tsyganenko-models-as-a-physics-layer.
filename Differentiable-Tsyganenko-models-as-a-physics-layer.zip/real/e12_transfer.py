"""E12: transfer between passes of the same regime (storm->storm, quiet->quiet) and blocked
within-pass validation, for regularized driver recalibration and the hybrid T04 + curl A_NN."""

import numpy as np, torch, json, time, sys, warnings
warnings.filterwarnings('ignore'); torch.set_num_threads(2)
sys.path.insert(0, '/home/claude/study')
from tsyg import t96, t01, t04
DT = torch.float64
D = np.genfromtxt('tha_1min_drivers.csv', delimiter=',', names=True)
M = np.load('inside_mask.npy'); inside, seg = M[:, 0].astype(bool), M[:, 1].astype(int)
B = np.column_stack([D['bx'], D['by'], D['bz']]); IG = np.column_stack([D['igx'], D['igy'], D['igz']])
bmag = np.linalg.norm(B, axis=1)
PASSES = {2: 'Q1 9 maj 11:25-17:30', 3: 'Q2 9 maj 18:26-23:23', 11: 'S1 10 maj 18:57-20:50', 12: 'S2 10 maj 21:46-23:46'}
use = inside & np.isin(seg, list(PASSES)) & (D['bstd'] / bmag < 0.2)
idx = np.where(use)[0]
T = lambda a: torch.tensor(np.asarray(a, dtype=float), dtype=DT)
X, Y, Z = T(D['x'][idx]), T(D['y'][idx]), T(D['z'][idx]); PS = T(D['tilt'][idx])
Bext = T(B[idx] - IG[idx]); SEG = seg[idx]
drv = {k: T(D[k][idx]) for k in ('pdyn', 'symh', 'imf_by', 'imf_bz', 'g1', 'g2', 'w1', 'w2', 'w3', 'w4', 'w5', 'w6')}
print('points per pass', {PASSES[k]: int((SEG == k).sum()) for k in PASSES}, flush=True)

def rmse(pred, m): return float(((pred[m] - Bext[m]) ** 2).sum(1).mean().sqrt())
def m_t96(p, b, dd, by, bz): return torch.stack(t96([p, dd, by, bz] + [0.] * 6, PS, X, Y, Z), 1)
def m_t04(p, dd, by, bz, w): return torch.stack(t04([p, dd, by, bz] + w, PS, X, Y, Z), 1)


with torch.no_grad():
    P96 = m_t96(drv['pdyn'], None, drv['symh'], drv['imf_by'], drv['imf_bz'])
    P04 = m_t04(drv['pdyn'], drv['symh'], drv['imf_by'], drv['imf_bz'], [drv[f'w{i}'] for i in range(1, 7)])
KAPPA = 100.0     # ridge weight (nT^2 per unit^2 of parameter deviation) pulling calibration toward identity
def cal_pred(model, th):
    if model == 'T96':
        a, b, c, d = th
        return m_t96(torch.exp(c) * drv['pdyn'], None, a * drv['symh'] + b, torch.exp(d) * drv['imf_by'], torch.exp(d) * drv['imf_bz'])
    c, dt_, dr, db = th          # Pdyn scale; W scales for tail (W1,W2), ring current (W3,W4), Birkeland (W5,W6)
    w = [torch.exp(dt_) * drv['w1'], torch.exp(dt_) * drv['w2'], torch.exp(dr) * drv['w3'], torch.exp(dr) * drv['w4'],
         torch.exp(db) * drv['w5'], torch.exp(db) * drv['w6']]
    return m_t04(torch.exp(c) * drv['pdyn'], drv['symh'], drv['imf_by'], drv['imf_bz'], w)
TH0 = {'T96': [1.0, 0.0, 0.0, 0.0], 'T04': [0.0, 0.0, 0.0, 0.0]}
def fit_cal(model, trn):
    th0 = torch.tensor(TH0[model], dtype=DT); th = th0.clone().requires_grad_(True)
    opt = torch.optim.LBFGS([th], lr=1, max_iter=80, line_search_fn='strong_wolfe', tolerance_grad=1e-9)
    def cl():
        opt.zero_grad()
        L = ((cal_pred(model, th)[trn] - Bext[trn]) ** 2).sum(1).mean() + KAPPA * ((th - th0) ** 2).sum()
        L.backward(); return L
    opt.step(cl)
    with torch.no_grad(): return th.detach(), cal_pred(model, th).detach()
feat = torch.stack([X / 10, Y / 10, Z / 10, drv['symh'] / 100], 1)
class Net(torch.nn.Module):
    def __init__(s, w=64):
        super().__init__(); s.f = torch.nn.Sequential(torch.nn.Linear(4, w), torch.nn.Tanh(), torch.nn.Linear(w, w), torch.nn.Tanh(),
                                                      torch.nn.Linear(w, w), torch.nn.Tanh(), torch.nn.Linear(w, 3)).double()
    def forward(s, f): return s.f(f)
def curl(net, f, cg=True):
    f = f.detach().requires_grad_(True); A = net(f)
    J = [torch.autograd.grad(A[:, i].sum(), f, create_graph=cg, retain_graph=True)[0][:, :3] / 10 for i in range(3)]  # d/dx = (1/10) d/df
    return 100.0 * torch.stack([J[2][:, 1] - J[1][:, 2], J[0][:, 2] - J[2][:, 0], J[1][:, 0] - J[0][:, 1]], 1)

def fit_hybrid(prior, trn, lam=1.0, N=2000):
    torch.manual_seed(0)
    net = Net(); opt = torch.optim.Adam(net.parameters(), 2e-3); sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, N)
    fc = feat[trn].clone()
    for it in range(N):
        opt.zero_grad()
        L = ((prior[trn] + curl(net, feat[trn]) - Bext[trn]) ** 2).sum(1).mean()
        fj = fc.clone(); fj[:, :3] += 0.1 * torch.randn(len(fc), 3, dtype=DT)
        L = L + lam * (curl(net, fj) ** 2).sum(1).mean()
        L.backward(); opt.step(); sch.step()
    return prior + curl(net, feat, False).detach()

def evaluate(trn, tst, label):
    trn_t = torch.tensor(trn)
    row = {'T96 (OMNI)': rmse(P96, tst), 'T04 (OMNI)': rmse(P04, tst)}
    th96, p96c = fit_cal('T96', trn_t); th04, p04c = fit_cal('T04', trn_t)
    row['T96-cal'] = rmse(p96c, tst); row['T04-cal'] = rmse(p04c, tst)
    row['T96-cal theta'] = th96.tolist(); row['T04-cal theta'] = th04.tolist()
    row['T04 + NN'] = rmse(fit_hybrid(P04, trn_t), tst)
    row['T04-cal + NN'] = rmse(fit_hybrid(p04c, trn_t), tst)
    row['n_train'] = int(trn.sum()); row['n_test'] = int(tst.sum())
    print(label, {k: (round(v, 1) if isinstance(v, float) else np.round(v, 2).tolist() if isinstance(v, list) else v) for k, v in row.items()}, flush=True)
    return row

res = {'kappa': KAPPA, 'lambda': 1.0, 'transfer': {}, 'blocked': {}}
for a, b in ((11, 12), (12, 11), (2, 3), (3, 2)):
    res['transfer'][f'{PASSES[a]} -> {PASSES[b]}'] = evaluate(SEG == a, SEG == b, f'{PASSES[a]} -> {PASSES[b]}')
# blocked within-pass validation: 10-min blocks, alternating, both folds; per regime
tmin = D['t'][idx]
block = ((tmin - tmin.min()) // 600).astype(int) % 2
for regime, segs in (('storm', (11, 12)), ('quiet', (2, 3))):
    r = np.isin(SEG, segs)
    for f in (0, 1):
        res['blocked'][f'{regime} fold{f}'] = evaluate(r & (block != f), r & (block == f), f'blocked {regime} fold{f}')
json.dump(res, open('results_e12_transfer.json', 'w'), indent=1)
print('done')
