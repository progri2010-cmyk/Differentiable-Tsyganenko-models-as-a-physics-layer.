"""Shue et al. (1998) magnetopause; in-magnetosphere selection and pass segmentation."""
import numpy as np, datetime as dt
D = np.genfromtxt('tha_1min_drivers.csv', delimiter=',', names=True)
def shue_r(theta, pdyn, bz):
    r0 = (10.22 + 1.29 * np.tanh(0.184 * (bz + 8.14))) * pdyn ** (-1 / 6.6)
    al = (0.58 - 0.007 * bz) * (1 + 0.024 * np.log(pdyn))
    return r0 * (2 / (1 + np.cos(theta))) ** al, r0
P = np.column_stack([D['x'], D['y'], D['z']]); r = np.linalg.norm(P, axis=1)
theta = np.arccos(np.clip(P[:, 0] / r, -1, 1))
rmp, r0 = shue_r(theta, D['pdyn'], D['imf_bz'])
drv_ok = np.isfinite(D['pdyn']) & np.isfinite(D['imf_bz']) & np.isfinite(D['imf_by']) & np.isfinite(D['symh'])
B = np.sqrt(D['bx']**2 + D['by']**2 + D['bz']**2)
inside = drv_ok & (r < rmp - 0.5) & (r > 2.0)
T = np.array([dt.datetime.fromtimestamp(x, dt.UTC) for x in D['t']])
print('driver availability', drv_ok.mean().round(3), '; inside & r>2:', inside.sum())
# contiguous segments
seg = np.zeros(len(D), int) - 1; s = -1
for i in range(len(D)):
    if inside[i]:
        if i == 0 or not inside[i-1] or D['t'][i] - D['t'][i-1] > 600: s += 1
        seg[i] = s
for k in range(s + 1):
    m = seg == k
    if m.sum() < 10: continue
    print(k, T[m][0].strftime('%d %H:%M'), '-', T[m][-1].strftime('%d %H:%M'), 'n', m.sum(),
          'r %.1f-%.1f' % (r[m].min(), r[m].max()), 'SYMH %.0f..%.0f' % (D['symh'][m].min(), D['symh'][m].max()),
          'Pdyn %.1f..%.1f' % (np.nanmin(D['pdyn'][m]), np.nanmax(D['pdyn'][m])), 'sig/B med %.3f' % np.median(D['bstd'][m]/B[m]),
          'r0 min %.1f' % r0[m].min())
# when are drivers missing?
miss = ~drv_ok
if miss.any(): print('drivers missing from', T[miss][0], 'to', T[miss][-1], 'count', miss.sum())
np.save('inside_mask.npy', np.column_stack([inside, seg, rmp]))
