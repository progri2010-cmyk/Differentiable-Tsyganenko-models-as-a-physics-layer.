import numpy as np, datetime as dt, torch, sys, cdflib, glob, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
sys.path.insert(0, '/home/claude/study'); import tsyg_torch as tt
plt.rcParams.update({'font.size': 8.5, 'axes.spines.top': False, 'axes.spines.right': False})
D = np.genfromtxt('tha_1min.csv', delimiter=',', names=True)
T = [dt.datetime.fromtimestamp(x, dt.UTC) for x in D['t']]
P = np.column_stack([D['x'], D['y'], D['z']]); B = np.column_stack([D['bx'], D['by'], D['bz']]); IG = np.column_stack([D['igx'], D['igy'], D['igz']])
r = np.linalg.norm(P, axis=1); Bm = np.linalg.norm(B, axis=1); Bext = B - IG
X = [torch.tensor(P[:, k]) for k in range(3)]
t89 = {s: torch.stack(tt.t89(*X, torch.tensor(D['tilt']), tt.t89_coeffs(iopt=s)), 1).numpy() for s in (2, 7)}
# AE
at, ae = [], []
for f in sorted(glob.glob('/home/claude/rawdata/*idx_2024*.cdf')):
    c = cdflib.CDF(f); at += list(c.varget('thg_idx_time')); ae += list(c.varget('thg_idx_ae'))
AT = [dt.datetime.fromtimestamp(x, dt.UTC) for x in at]
day = np.array([x.day for x in T]); sel = day <= 11
fig, ax = plt.subplots(5, 1, figsize=(11, 9), sharex=True, constrained_layout=True)
Ts = [x for x, s in zip(T, sel) if s]
ax[0].plot(AT, ae, lw=.6, c='#0b0b0b'); ax[0].set_ylabel('AE (nT)')
ax[1].plot(Ts, r[sel], '.', ms=1.5, c='#0b0b0b'); ax[1].set_ylabel('r (Re)')
ax2 = ax[1].twinx(); ax2.plot(Ts, P[sel, 0], '.', ms=1, c='#eb6834'); ax2.set_ylabel('X$_{GSM}$', color='#eb6834')
ax[2].semilogy(Ts, Bm[sel], '.', ms=1.5, c='#0b0b0b', label='|B| matur'); ax[2].semilogy(Ts, np.linalg.norm(IG, axis=1)[sel], '.', ms=1, c='#2a78d6', label='|IGRF|')
ax[2].set_ylabel('nT'); ax[2].legend(frameon=False, markerscale=6)
ax[3].plot(Ts, (D['bstd'] / Bm)[sel], '.', ms=1.5, c='#0b0b0b'); ax[3].set_yscale('log'); ax[3].set_ylabel('σ$_{1min}$/|B|')
ax[4].plot(Ts, Bext[sel, 2], '.', ms=1.5, c='#0b0b0b', label='Bz$_{ext}$ = Bz − IGRF')
for s, col in ((2, '#1baf7a'), (7, '#eb6834')): ax[4].plot(Ts, t89[s][sel, 2], '.', ms=1, c=col, label=f'T89 iopt={s}')
ax[4].set_ylim(-300, 300); ax[4].set_ylabel('nT'); ax[4].legend(frameon=False, markerscale=6, ncol=3)
fig.savefig('look.png', dpi=130)
