import json, numpy as np, torch, datetime as dt, sys, warnings, matplotlib; matplotlib.use('Agg'); warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
sys.path.insert(0, '/home/claude/study'); from tsyg import t96, t01, t04
plt.rcParams.update({'font.size': 8.5, 'axes.spines.top': False, 'axes.spines.right': False})
D = np.genfromtxt('tha_1min_drivers.csv', delimiter=',', names=True); idx = np.load('e11_index.npy'); M = np.load('inside_mask.npy')
seg = M[idx, 1].astype(int); st = np.isin(seg, (11, 12))
T = lambda a: torch.tensor(np.asarray(a, float))
g = {k: T(D[k][idx][st]) for k in D.dtype.names}
with torch.no_grad():
    P = {'T96': t96([g['pdyn'], g['symh'], g['imf_by'], g['imf_bz']] + [0.]*6, g['tilt'], g['x'], g['y'], g['z']),
         'T01': t01([g['pdyn'], g['symh'], g['imf_by'], g['imf_bz'], g['g1'], g['g2']] + [0.]*4, g['tilt'], g['x'], g['y'], g['z']),
         'T04': t04([g['pdyn'], g['symh'], g['imf_by'], g['imf_bz']] + [g[f'w{i}'] for i in range(1, 7)], g['tilt'], g['x'], g['y'], g['z'])}
obs = np.column_stack([g['bx'] - g['igx'], g['by'] - g['igy'], g['bz'] - g['igz']])
tt = [dt.datetime.fromtimestamp(x, dt.UTC) for x in D['t'][idx][st]]
C = {'T96': '#2a78d6', 'T01': '#1baf7a', 'T04': '#eb6834'}
fig = plt.figure(figsize=(11, 7.5), constrained_layout=True); gs = fig.add_gridspec(3, 2)
for j, comp in enumerate(('B$_x$', 'B$_z$')):
    ax = fig.add_subplot(gs[0, j]); k = 0 if j == 0 else 2
    ax.plot(tt, obs[:, k], '.', ms=2.5, c='#0b0b0b', label='THEMIS-A − IGRF')
    for n, p in P.items(): ax.plot(tt, p[k].numpy(), '.', ms=1.5, c=C[n], label=f'{n} (OMNI)')
    ax.set_ylabel(f'{comp}$_{{ext}}$ (nT)'); ax.set_title(f'(a{j+1}) Storm passes S1 and S2, 10 May 2024: external {comp}', fontsize=8.5)
    if j == 0: ax.legend(frameon=False, markerscale=5, fontsize=7.5)
    ax.tick_params(axis='x', labelsize=7)
r11 = json.load(open('results_e11_real.json'))['fixed_models']; r12 = json.load(open('results_e12_transfer.json'))
ax = fig.add_subplot(gs[1, :])
names = ['IGRF only', 'T96 (OMNI)', 'T96 clamped', 'T01 (OMNI)', 'T04 (OMNI)']; passes = list(r11['IGRF only'].keys())
cols = ['#b5b5b0', '#2a78d6', '#7fb2ec', '#1baf7a', '#eb6834']; w = 0.16
for i, n in enumerate(names):
    ax.bar(np.arange(4) + (i - 2) * w, [r11[n][p] for p in passes], w * 0.92, color=cols[i], label=n.replace('IGRF only', 'IGRF only (B$_{ext}$=0)').replace('clamped', 'with clipped drivers'))
ax.set_yscale('log'); ax.set_xticks(range(4)); ax.set_xticklabels([p.replace('maj', 'May').replace('-', '–') for p in passes]); ax.set_ylabel('RMSE of |ΔB$_{ext}$| (nT)')
ax.set_ylim(5, 3000); ax.legend(frameon=False, ncol=5, fontsize=7.5, loc='upper left'); ax.set_title('(b) Empirical models with OMNI drivers, per pass inside the magnetosphere', fontsize=8.5)
ax = fig.add_subplot(gs[2, :])
sets = [('blocked', 'storm fold0'), ('blocked', 'storm fold1'), ('blocked', 'quiet fold0'), ('blocked', 'quiet fold1')] + [('transfer', k) for k in r12['transfer']]
lab = ['storm, blocks 0', 'storm, blocks 1', 'quiet, blocks 0', 'quiet, blocks 1'] + ['S1→S2', 'S2→S1', 'Q1→Q2', 'Q2→Q1']
meths = ['T04 (OMNI)', 'T96 (OMNI)', 'T96-cal', 'T04 + NN']; mc = ['#eb6834', '#2a78d6', '#1f4e8c', '#7b4bc4']
for i, m in enumerate(meths):
    ax.bar(np.arange(len(sets)) + (i - 1.5) * 0.2, [r12[a][b][m] for a, b in sets], 0.18, color=mc[i],
           label=m.replace('T96-cal', 'T96, recalibrated drivers').replace('T04 + NN', 'hybrid T04 + curl A$_{NN}$'))
ax.set_yscale('log'); ax.set_xticks(range(len(sets))); ax.set_xticklabels(lab, fontsize=7.5); ax.set_ylabel('RMSE test (nT)')
ax.set_ylim(4, 3000); ax.legend(frameon=False, ncol=4, fontsize=7.5, loc='upper left'); ax.set_title('(c) Test errors: 10-min blocks within passes, and transfer between passes of the same regime', fontsize=8.5)
fig.savefig('fig_real_themis_en.png', dpi=160); print('ok')
