"""Build a 1-min THEMIS-A dataset: position (GSM, Re), B_obs (GSM, nT), sub-minute variability, IGRF, tilt."""
import cdflib, glob, numpy as np, datetime as dt, sys
from geopack import geopack as gp
src = '/home/claude/rawdata/tha'
st_t, st_p = [], []
for f in sorted(glob.glob(f'{src}/*state*.cdf'), key=lambda s: s.split('_')[-2]):
    c = cdflib.CDF(f); st_t.append(c.varget('tha_state_time')); st_p.append(c.varget('tha_pos_gsm') / 6371.2)
st_t, st_p = np.concatenate(st_t), np.concatenate(st_p)
o = np.argsort(st_t); st_t, st_p = st_t[o], st_p[o]
ft, fb = [], []
for f in sorted(glob.glob(f'{src}/*fgm*.cdf'), key=lambda s: s.split('_')[-2]):
    c = cdflib.CDF(f); t = c.varget('tha_fgs_time'); b = c.varget('tha_fgs_gsm')
    ok = np.isfinite(b).all(1) & (np.abs(b) < 1e5).all(1); ft.append(t[ok]); fb.append(b[ok])
ft, fb = np.concatenate(ft), np.concatenate(fb)
o = np.argsort(ft); ft, fb = ft[o], fb[o]
_, u = np.unique(ft, return_index=True); ft, fb = ft[u], fb[u]
# 1-min bins centred on the state epochs
edges = np.concatenate([st_t - 30, [st_t[-1] + 30]])
idx = np.searchsorted(edges, ft) - 1
rows = []
for k in range(len(st_t)):
    m = idx == k
    if m.sum() < 10: continue                      # need >= 10 spin samples (~30 s) in the minute
    b = fb[m]; bm = b.mean(0)
    rows.append([st_t[k], *st_p[k], *bm, np.linalg.norm(b.std(0)), m.sum()])
R = np.array(rows)
# IGRF and tilt per minute
ig, ps = [], []
for r in R:
    ps.append(gp.recalc(r[0])); ig.append(gp.igrf_gsm(*r[1:4]))
R = np.column_stack([R, np.array(ig), np.array(ps)])
cols = 't,x,y,z,bx,by,bz,bstd,nsamp,igx,igy,igz,tilt'
np.savetxt('tha_1min.csv', R, delimiter=',', header=cols, comments='', fmt='%.6f')
print(R.shape, 'minutes with data;', dt.datetime.fromtimestamp(R[0, 0], dt.UTC), '->', dt.datetime.fromtimestamp(R[-1, 0], dt.UTC))
