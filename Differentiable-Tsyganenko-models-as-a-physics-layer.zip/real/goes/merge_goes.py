import numpy as np, datetime as dt, sys
sys.path.insert(0, '/home/claude/study/real')
from drivers import load_omni, g_indices, w_indices
t0 = dt.datetime(2024, 5, 9, tzinfo=dt.UTC).timestamp(); t1 = dt.datetime(2024, 5, 15, tzinfo=dt.UTC).timestamp()
o = load_omni(t0, t1); G1, G2 = g_indices(o); W = w_indices(o)
D = np.genfromtxt('g18_1min.csv', delimiter=',', names=True)
ii = np.clip(np.searchsorted(o['t'], D['t'] - 30), 0, len(o['t']) - 1)     # OMNI minute that contains the GOES minute centre
ok = np.abs(o['t'][ii] - (D['t'] - 30)) < 1
cols = {n: D[n] for n in D.dtype.names}
for k, v in (('pdyn', o['Pdyn']), ('symh', o['SYM_H']), ('imf_by', o['BY_GSM']), ('imf_bz', o['BZ_GSM']),
             ('vsw', o['flow_speed']), ('nsw', o['proton_density']), ('g1', G1), ('g2', G2)):
    cols[k] = np.where(ok, v[ii], np.nan)
for j in range(6): cols[f'w{j+1}'] = np.where(ok, W[ii, j], np.nan)
# Shue (1998) magnetopause
P = np.column_stack([D['x'], D['y'], D['z']]); r = np.linalg.norm(P, axis=1); th = np.arccos(np.clip(P[:, 0] / r, -1, 1))
bz, pd = cols['imf_bz'], cols['pdyn']
r0 = (10.22 + 1.29 * np.tanh(0.184 * (bz + 8.14))) * pd ** (-1 / 6.6); al = (0.58 - 0.007 * bz) * (1 + 0.024 * np.log(pd))
cols['r_mp'] = r0 * (2 / (1 + np.cos(th))) ** al
cols['inside'] = (r < cols['r_mp'] - 0.5).astype(float)
names = list(cols)
np.savetxt('g18_1min_drivers.csv', np.column_stack([cols[n] for n in names]), delimiter=',', header=','.join(names), comments='', fmt='%.6f')
B = np.sqrt(D['bx']**2 + D['by']**2 + D['bz']**2)
print('merged', int(ok.sum()), '/', len(D), '; outside (Shue) minutes', int((cols['inside'] == 0).sum()), '; min r_mp at GOES %.2f' % np.nanmin(cols['r_mp']))
out = cols['inside'] == 0
T = [dt.datetime.fromtimestamp(x, dt.UTC) for x in D['t'][out]]
if out.any(): print('outside intervals start', T[0], 'end', T[-1], 'Bz_obs min there %.0f' % D['bz'][out].min())
for d in (9, 10, 11, 12, 13, 14):
    m = np.array([dt.datetime.fromtimestamp(x, dt.UTC).day == d for x in D['t']])
    print(d, 'n', m.sum(), 'SYMH %.0f..%.0f' % (np.nanmin(cols['symh'][m]), np.nanmax(cols['symh'][m])), 'Pdyn max %.1f' % np.nanmax(pd[m]), '|B| %.0f..%.0f' % (B[m].min(), B[m].max()))
