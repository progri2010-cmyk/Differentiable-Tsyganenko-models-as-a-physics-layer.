"""
E13b: two spacecraft. GOES-18 (geosynchronous, 9 and 11-14 May 2024) and THEMIS-A (4 passes, 9-10 May).

(1) leave-one-day-out on GOES-18
(2) train on GOES-18 (all days), test on the THEMIS-A passes: different spacecraft, different radial
    distances (GOES only samples r = 6.6 Re) and, for the storm passes, different times (10 May
    18:57-23:46 UT, when GOES-18 data were not provided)

Methods: T04 and T96 with OMNI drivers; ridge-regularised driver recalibration through the
differentiable model (T96-cal, T04-cal); hybrid prior + curl_x A_NN(x, drivers) on top of T04
and on top of T96-cal.
"""
import numpy as np, torch, json, datetime as dt, sys, time, warnings
warnings.filterwarnings('ignore'); torch.set_num_threads(2)
sys.path.insert(0, '/home/claude/study'); from tsyg import t96, t04
DT = torch.float64
T = lambda a: torch.tensor(np.asarray(a, float), dtype=DT)
KEYS = ('x', 'y', 'z', 'tilt', 'pdyn', 'symh', 'imf_by', 'imf_bz', 'w1', 'w2', 'w3', 'w4', 'w5', 'w6')

def pack(D, m):
    g = {k: T(D[k][m]) for k in KEYS}
    g['obs'] = torch.stack([T(D['bx'][m] - D['igx'][m]), T(D['by'][m] - D['igy'][m]), T(D['bz'][m] - D['igz'][m])], 1)
    g['t'] = D['t'][m]
    return g
G = np.genfromtxt('g18_1min_drivers.csv', delimiter=',', names=True)
gm = G['inside'] == 1
GO = pack(G, gm); gday = np.array([dt.datetime.fromtimestamp(x, dt.UTC).day for x in GO['t']])
H = np.genfromtxt('../tha_1min_drivers.csv', delimiter=',', names=True)
idx = np.load('../e11_index.npy'); seg = np.load('../inside_mask.npy')[idx, 1].astype(int)
TH = pack(H, idx)
PASSES = {2: 'Q1', 3: 'Q2', 11: 'S1', 12: 'S2'}

def sub(g, m):
    m = torch.as_tensor(m)
    return {k: (v[m] if isinstance(v, torch.Tensor) else v[m.numpy()]) for k, v in g.items()}
def rmse(p, g): return float(((p - g['obs']) ** 2).sum(1).mean().sqrt())

def m96(g, th=None):
    a, b, c, d = th if th is not None else (1., 0., torch.tensor(0.), torch.tensor(0.))
    return torch.stack(t96([torch.exp(c) * g['pdyn'], a * g['symh'] + b, torch.exp(d) * g['imf_by'], torch.exp(d) * g['imf_bz']] + [0.] * 6,
                           g['tilt'], g['x'], g['y'], g['z']), 1)
def m04(g, th=None):
    c, dt_, dr, db = th if th is not None else [torch.tensor(0.)] * 4
    w = [torch.exp(dt_) * g['w1'], torch.exp(dt_) * g['w2'], torch.exp(dr) * g['w3'], torch.exp(dr) * g['w4'],
         torch.exp(db) * g['w5'], torch.exp(db) * g['w6']]
    return torch.stack(t04([torch.exp(c) * g['pdyn'], g['symh'], g['imf_by'], g['imf_bz']] + w, g['tilt'], g['x'], g['y'], g['z']), 1)
TH0 = {'T96': [1., 0., 0., 0.], 'T04': [0., 0., 0., 0.]}
KAPPA = 100.0
def fit_cal(model, g):
    f = m96 if model == 'T96' else m04
    th0 = torch.tensor(TH0[model], dtype=DT); th = th0.clone().requires_grad_(True)
    opt = torch.optim.LBFGS([th], lr=1, max_iter=60, line_search_fn='strong_wolfe', tolerance_grad=1e-8)
    def cl():
        opt.zero_grad(); L = ((f(g, th) - g['obs']) ** 2).sum(1).mean() + KAPPA * ((th - th0) ** 2).sum(); L.backward(); return L
    opt.step(cl)
    return th.detach()

def feats(g):
    return torch.stack([g['x'] / 10, g['y'] / 10, g['z'] / 10, g['symh'] / 100, torch.log(g['pdyn']) / 3, g['imf_bz'] / 20, g['imf_by'] / 20], 1)
class Net(torch.nn.Module):
    def __init__(s, w=64):
        super().__init__(); s.f = torch.nn.Sequential(torch.nn.Linear(7, w), torch.nn.Tanh(), torch.nn.Linear(w, w), torch.nn.Tanh(),
                                                      torch.nn.Linear(w, w), torch.nn.Tanh(), torch.nn.Linear(w, 3)).double()
    def forward(s, f): return s.f(f)
def curl(net, f, cg=True):
    f = f.detach().requires_grad_(True); A = net(f)
    J = [torch.autograd.grad(A[:, i].sum(), f, create_graph=cg, retain_graph=True)[0][:, :3] / 10 for i in range(3)]
    return 100.0 * torch.stack([J[2][:, 1] - J[1][:, 2], J[0][:, 2] - J[2][:, 0], J[1][:, 0] - J[0][:, 1]], 1)
def fit_hybrid(prior_tr, g, lam=1.0, N=2000, jitter=0.1):
    torch.manual_seed(0); net = Net(); opt = torch.optim.Adam(net.parameters(), 2e-3)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, N); F = feats(g)
    for it in range(N):
        opt.zero_grad()
        L = ((prior_tr + curl(net, F) - g['obs']) ** 2).sum(1).mean()
        Fj = F.clone(); Fj[:, :3] += jitter * torch.randn(len(F), 3, dtype=DT)
        L = L + lam * (curl(net, Fj) ** 2).sum(1).mean()
        L.backward(); opt.step(); sch.step()
    return net

def run_all(train, tests, label):
    """train: dict of tensors; tests: {name: dict}. Returns RMSE per method per test set."""
    t0 = time.perf_counter()
    with torch.no_grad():
        p04_tr = m04(train)
    th96 = fit_cal('T96', train); th04 = fit_cal('T04', train)
    with torch.no_grad(): p96c_tr = m96(train, th96)
    net04 = fit_hybrid(p04_tr, train); net96c = fit_hybrid(p96c_tr, train)
    out = {'theta_T96cal': th96.tolist(), 'theta_T04cal': th04.tolist(), 'n_train': int(len(train['obs']))}
    for name, g in tests.items():
        with torch.no_grad():
            p04, p96 = m04(g), m96(g); p96c, p04c = m96(g, th96), m04(g, th04)
        h04 = p04 + curl(net04, feats(g), False).detach(); h96c = p96c + curl(net96c, feats(g), False).detach()
        out[name] = {'T04 (OMNI)': rmse(p04, g), 'T96 (OMNI)': rmse(p96, g), 'T96-cal': rmse(p96c, g), 'T04-cal': rmse(p04c, g),
                     'T04 + NN': rmse(h04, g), 'T96-cal + NN': rmse(h96c, g), 'n': int(len(g['obs']))}
        print(label, '->', name, {k: round(v, 1) for k, v in out[name].items()}, flush=True)
    print(label, 'theta96', np.round(th96.numpy(), 3), 'theta04', np.round(th04.numpy(), 3), 'time %.0f s' % (time.perf_counter() - t0), flush=True)
    return out

res = {'kappa': KAPPA, 'lambda': 1.0, 'goes_minutes_inside': int(gm.sum()), 'goes_train_cadence_min': 3}
# (2) GOES -> THEMIS
thin = np.zeros(len(GO['obs']), bool); thin[::3] = True
res['goes_to_themis'] = run_all(sub(GO, thin), {PASSES[k]: sub(TH, seg == k) for k in PASSES}, 'GOES(all)')
json.dump(res, open('results_e13b_multisat.json', 'w'), indent=1)
# (1) leave-one-day-out on GOES
res['goes_lodo'] = {}
for d in (9, 10, 11, 12, 13, 14):
    trm = (gday != d) & thin
    res['goes_lodo'][f'{d} maj'] = run_all(sub(GO, trm), {f'GOES {d} maj': sub(GO, gday == d)}, f'GOES lodo {d}')
    json.dump(res, open('results_e13b_multisat.json', 'w'), indent=1)
print('done')
