"""GOES-18 MAG L2 hires (10 Hz) -> 1-min averages of B_GSM with position converted GEO -> GSM (geopack)."""
import netCDF4 as nc, numpy as np, glob, datetime as dt, sys
from geopack import geopack as gp
J2000 = dt.datetime(2000, 1, 1, 12, tzinfo=dt.UTC).timestamp()
rows = []
for f in sorted(glob.glob('/mnt/user-data/uploads/dn_magn-l2-hires_g18_d*.nc')):
    d = nc.Dataset(f); d.set_auto_mask(False)
    t = d['time'][:] + J2000; b = d['b_gsm'][:].astype(float); q = d['b_quality'][:]; dqf = d['DQF'][:]
    to = d['time_orbit'][:] + J2000; llr = d['orbit_llr_geo'][:].astype(float)
    # b_quality is not populated in this product version (all fill); use DQF with the informational
    # 'valid_arcjet_correction' bit (33554432) masked out, plus the -9999 fill of b_gsm
    good = ((dqf & 33554431) == 0) & (dqf != 4294967295) & np.isfinite(b).all(1) & (np.abs(b) < 1024).all(1)
    print(f.split('_d')[-1][:8], 'samples', len(t), 'good %.3f' % good.mean(), 'quality values', np.unique(q)[:6], 'DQF nonzero %.3f' % (dqf != 0).mean())
    t, b = t[good], b[good]
    m0 = np.floor(t / 60) * 60
    keys, inv, cnt = np.unique(m0, return_inverse=True, return_counts=True)
    sb = np.zeros((len(keys), 3)); np.add.at(sb, inv, b); sb /= cnt[:, None]
    sb2 = np.zeros((len(keys), 3)); np.add.at(sb2, inv, b ** 2); sd = np.sqrt(np.clip(sb2 / cnt[:, None] - sb ** 2, 0, None))
    for k in range(len(keys)):
        if cnt[k] < 300: continue                        # >= 30 s of 10-Hz data
        tc = keys[k] + 30
        j = np.clip(np.searchsorted(to, tc), 0, len(to) - 1)
        lat, lon, rad = llr[j]
        r = rad / 6371200.0; th = np.radians(90 - lat); ph = np.radians(lon)
        xg, yg, zg = r * np.sin(th) * np.cos(ph), r * np.sin(th) * np.sin(ph), r * np.cos(th)
        ps = gp.recalc(tc)
        xs, ys, zs = gp.geogsm(xg, yg, zg, 1)
        ig = gp.igrf_gsm(xs, ys, zs)
        rows.append([tc, xs, ys, zs, *sb[k], np.linalg.norm(sd[k]), cnt[k], *ig, ps])
R = np.array(rows)
np.savetxt('g18_1min.csv', R, delimiter=',', header='t,x,y,z,bx,by,bz,bstd,nsamp,igx,igy,igz,tilt', comments='', fmt='%.6f')
r = np.linalg.norm(R[:, 1:4], axis=1)
print(R.shape, 'r %.3f-%.3f' % (r.min(), r.max()), dt.datetime.fromtimestamp(R[0, 0], dt.UTC), dt.datetime.fromtimestamp(R[-1, 0], dt.UTC))
