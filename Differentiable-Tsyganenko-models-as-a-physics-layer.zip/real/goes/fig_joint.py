import json, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 8.5, 'axes.spines.top': False, 'axes.spines.right': False})
r = json.load(open('results_e14_joint.json')); ps = ['Q1', 'Q2', 'S1', 'S2']
series = [('T04 (OMNI)', lambda p: r['goes_to_themis'][p]['T04 (OMNI)'], '#eb6834'),
          ('T96 (OMNI)', lambda p: r['goes_to_themis'][p]['T96 (OMNI)'], '#2a78d6'),
          ('T96-cal, vetëm THEMIS', lambda p: r['themis_only_lopo'][p][p]['T96-cal'], '#9cc3ef'),
          ('T96-cal, vetëm GOES', lambda p: r['goes_to_themis'][p]['T96-cal'], '#3d6fb6'),
          ('T96-cal, GOES + THEMIS', lambda p: r['joint_lopo'][p][p]['T96-cal'], '#16365f'),
          ('T04 + NN, vetëm THEMIS', lambda p: r['themis_only_lopo'][p][p]['T04 + NN'], '#d6c3f0'),
          ('T04 + NN, vetëm GOES', lambda p: r['goes_to_themis'][p]['T04 + NN'], '#9a6fd6'),
          ('T04 + NN, GOES + THEMIS', lambda p: r['joint_lopo'][p][p]['T04 + NN'], '#4b2a8a')]
fig, ax = plt.subplots(1, 2, figsize=(11.5, 3.9), constrained_layout=True, gridspec_kw=dict(width_ratios=[2.3, 1]))
w = 0.105
for i, (lab, f, c) in enumerate(series):
    ax[0].bar(np.arange(4) + (i - 3.5) * w, [f(p) for p in ps], w * 0.92, color=c, label=lab)
ax[0].set_yscale('log'); ax[0].set_ylim(4, 3000); ax[0].set_xticks(range(4))
ax[0].set_xticklabels(['THEMIS-A Q1 (9 maj)', 'Q2 (9 maj)', 'S1 (10 maj, stuhi)', 'S2 (10 maj, stuhi)'])
ax[0].set_ylabel('RMSE test (nT)'); ax[0].legend(frameon=False, ncol=4, fontsize=7, loc='upper left')
ax[0].set_title('(a) Kalimi i THEMIS-A i mbajtur jashtë, sipas burimit të të dhënave të trajnimit', fontsize=8.5)
pts = {'vetëm GOES': [r['goes_to_themis']['theta_T96cal']] + [r['goes_lodo'][d]['theta_T96cal'] for d in r['goes_lodo']],
       'GOES + THEMIS': [r['joint_lopo'][p]['theta_T96cal'] for p in ps],
       'vetëm THEMIS': [r['themis_only_lopo'][p]['theta_T96cal'] for p in ps]}
for (lab, th), c, mk in zip(pts.items(), ('#3d6fb6', '#16365f', '#9cc3ef'), ('o', 's', '^')):
    th = np.array(th); ax[1].scatter(th[:, 0], np.exp(th[:, 3]), s=40, c=c, marker=mk, label=lab, edgecolors='white', linewidths=1.2)
ax[1].axvline(1, c='#bbb', lw=.7); ax[1].axhline(1, c='#bbb', lw=.7)
ax[1].set_xlabel('koeficienti efektiv i Dst, a'); ax[1].set_ylabel('faktori i IMF, e$^d$'); ax[1].legend(frameon=False, fontsize=7.5)
ax[1].set_title('(b) Parametrat e rikalibruar të T96', fontsize=8.5); ax[1].set_xlim(0, 1.1); ax[1].set_ylim(0, 1.15)
fig.savefig('fig_joint.png', dpi=160); print('ok')
