import json, numpy as np, datetime as dt, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 8.5, 'axes.spines.top': False, 'axes.spines.right': False})
D = np.genfromtxt('g18_1min_drivers.csv', delimiter=',', names=True); m = D['inside'] == 1
P = np.load('g18_pred_fixed.npy')   # IGRF, T96, T01, T04
tt = np.array([dt.datetime.fromtimestamp(x, dt.UTC) for x in D['t'][m]])
obs_bz = (D['bz'] - D['igz'])[m]
fig = plt.figure(figsize=(11, 8), constrained_layout=True); gs = fig.add_gridspec(3, 2)
ax = fig.add_subplot(gs[0, :])
def gapped(t, y):
    t = np.array(t, dtype=object); y = np.array(y, float); br = np.where(np.diff([x.timestamp() for x in t]) > 600)[0] + 1
    return np.split(t, br), np.split(y, br)
for y, c, lab, lw in ((obs_bz, '#0b0b0b', 'GOES-18 − IGRF', 1.0), (P[1][:, 2], '#2a78d6', 'T96 (OMNI)', .8), (P[3][:, 2], '#eb6834', 'T04 (OMNI)', .8)):
    ts, ys = gapped(tt, y)
    for i, (a, b) in enumerate(zip(ts, ys)): ax.plot(a, b, c=c, lw=lw, label=lab if i == 0 else None)
ax.set_ylabel('B$_{z,ext}$ (nT)'); ax.legend(frameon=False, ncol=3, fontsize=7.5, loc='lower right')
ax.set_title('(a) GOES-18 at geosynchronous orbit, 9–14 May 2024 (minutes inside the magnetosphere)', fontsize=8.5)
ax2 = ax.twinx()
for a, b in zip(*gapped(tt, D['symh'][m])): ax2.plot(a, b, c='#999', lw=.6); ax2.set_ylabel('SYM-H (nT)', color='#777')
r = json.load(open('results_e14_joint.json')); fx = json.load(open('results_e13a_goes_fixed.json'))
meth = ['T04 (OMNI)', 'T96 (OMNI)', 'T96-cal', 'T04-cal', 'T04 + NN', 'T96-cal + NN']
lab = {'T04 (OMNI)': 'T04 (OMNI)', 'T96 (OMNI)': 'T96 (OMNI)', 'T96-cal': 'T96 recalibrated', 'T04-cal': 'T04 recalibrated', 'T04 + NN': 'T04 + curl A$_{NN}$', 'T96-cal + NN': 'T96 recal. + curl A$_{NN}$'}
col = ['#eb6834', '#2a78d6', '#1f4e8c', '#f2a07b', '#7b4bc4', '#3fa3a0']
ax = fig.add_subplot(gs[1, :]); days = list(r['goes_lodo'])
for i, mt in enumerate(meth):
    ax.bar(np.arange(len(days)) + (i - 2.5) * 0.14, [r['goes_lodo'][d][f'GOES {d}'][mt] for d in days], 0.13, color=col[i], label=lab[mt])
ax.bar(np.arange(len(days)) - 3.5 * 0.14, [fx['IGRF only'][d] for d in days], 0.13, color='#b5b5b0', label='IGRF only')
ax.set_yscale('log'); ax.set_ylim(3, 1500); ax.set_xticks(range(len(days))); ax.set_xticklabels([f'GOES-18, {d.replace("maj", "May")}' for d in days])
ax.set_ylabel('RMSE test (nT)'); ax.legend(frameon=False, ncol=7, fontsize=7, loc='upper left')
ax.set_title('(b) Leave one day out: trained on the other GOES-18 days, tested on the held-out day', fontsize=8.5)
ax = fig.add_subplot(gs[2, :]); ps = ['Q1', 'Q2', 'S1', 'S2']
for i, mt in enumerate(meth):
    ax.bar(np.arange(4) + (i - 2.5) * 0.14, [r['goes_to_themis'][p][mt] for p in ps], 0.13, color=col[i], label=lab[mt])
ax.set_yscale('log'); ax.set_ylim(3, 1500); ax.set_xticks(range(4)); ax.set_xticklabels(['THEMIS-A Q1 (9 May)', 'Q2 (9 May)', 'S1 (10 May, storm)', 'S2 (10 May, storm)'])
ax.set_ylabel('RMSE test (nT)'); ax.legend(frameon=False, ncol=6, fontsize=7, loc='upper left')
ax.set_title('(c) Another spacecraft: trained on all GOES-18 data, tested on the THEMIS-A passes', fontsize=8.5)
fig.savefig('fig_goes_multisat_v2.png', dpi=160); print('ok')
