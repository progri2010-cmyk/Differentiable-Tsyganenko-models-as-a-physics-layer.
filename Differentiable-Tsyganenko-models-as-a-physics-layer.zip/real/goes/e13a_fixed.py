import numpy as np, torch, json, datetime as dt, sys, warnings; warnings.filterwarnings('ignore'); torch.set_num_threads(2)
sys.path.insert(0, '/home/claude/study'); from tsyg import t96, t01, t04
D = np.genfromtxt('g18_1min_drivers.csv', delimiter=',', names=True); m = D['inside'] == 1
T = lambda a: torch.tensor(np.asarray(a, float))
g = {k: T(D[k][m]) for k in D.dtype.names}
obs = torch.stack([g['bx'] - g['igx'], g['by'] - g['igy'], g['bz'] - g['igz']], 1)
with torch.no_grad():
    P = {'IGRF only': torch.zeros_like(obs),
         'T96 (OMNI)': torch.stack(t96([g['pdyn'], g['symh'], g['imf_by'], g['imf_bz']] + [0.]*6, g['tilt'], g['x'], g['y'], g['z']), 1),
         'T01 (OMNI)': torch.stack(t01([g['pdyn'], g['symh'], g['imf_by'], g['imf_bz'], g['g1'], g['g2']] + [0.]*4, g['tilt'], g['x'], g['y'], g['z']), 1),
         'T04 (OMNI)': torch.stack(t04([g['pdyn'], g['symh'], g['imf_by'], g['imf_bz']] + [g[f'w{i}'] for i in range(1, 7)], g['tilt'], g['x'], g['y'], g['z']), 1)}
day = np.array([dt.datetime.fromtimestamp(x, dt.UTC).day for x in D['t'][m]])
res = {}
for n, p in P.items():
    e = ((p - obs) ** 2).sum(1)
    res[n] = {f'{d} maj': float(e[torch.tensor(day == d)].mean().sqrt()) for d in (9, 10, 11, 12, 13, 14)}
    res[n]['all'] = float(e.mean().sqrt())
    print(n, {k: round(v, 1) for k, v in res[n].items()})
np.save('g18_pred_fixed.npy', np.stack([P[k].numpy() for k in P]))
json.dump(res, open('results_e13a_goes_fixed.json', 'w'), indent=1)
