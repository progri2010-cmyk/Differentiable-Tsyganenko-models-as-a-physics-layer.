"""
E11: THEMIS-A during the 9-11 May 2024 storm. Observed external field B_ext = B_FGM - IGRF inside the
magnetosphere (Shue 1998 magnetopause, 0.5 Re margin, r > 2 Re) compared with

  IGRF only          (B_ext = 0)
  T96, T01, T04      with OMNI drivers (Pdyn, SYM-H as Dst, IMF By/Bz, G1-G2, W1-W6)
  T96 clamped        drivers clipped to the T96 calibration range
  T96-cal, T04-cal   drivers recalibrated through the differentiable model
                     (Dst_eff = a SYMH + b, Pdyn_eff = e^c Pdyn, IMF or W scaled by e^d)
  T04 + NN           hybrid: T04(OMNI) + curl_x A_NN(x, drivers), divergence-free in x

Evaluation is leave-one-pass-out over the four in-magnetosphere passes (two quiet, two storm-time):
everything that is fitted is fitted on three passes and scored on the fourth.
"""
import numpy as np, torch, json, time, sys, warnings
warnings.filterwarnings('ignore'); torch.set_num_threads(2)
sys.path.insert(0, '/home/claude/study')
from tsyg import t96, t01, t04
DT = torch.float64
D = np.genfromtxt('tha_1min_drivers.csv', delimiter=',', names=True)
M = np.load('inside_mask.npy'); inside, seg = M[:, 0].astype(bool), M[:, 1].astype(int)
B = np.column_stack([D['bx'], D['by'], D['bz']]); IG = np.column_stack([D['igx'], D['igy'], D['igz']])
bmag = np.linalg.norm(B, axis=1)
PASSES = {2: 'Q1 9 maj 11:25-17:30', 3: 'Q2 9 maj 18:26-23:23', 11: 'S1 10 maj 18:57-20:50', 12: 'S2 10 maj 21:46-23:46'}
use = inside & np.isin(seg, list(PASSES)) & (D['bstd'] / bmag < 0.2)
idx = np.where(use)[0]
T = lambda a: torch.tensor(np.asarray(a, dtype=float), dtype=DT)
X, Y, Z = T(D['x'][idx]), T(D['y'][idx]), T(D['z'][idx]); PS = T(D['tilt'][idx])
Bext = T(B[idx] - IG[idx]); SEG = seg[idx]
drv = {k: T(D[k][idx]) for k in ('pdyn', 'symh', 'imf_by', 'imf_bz', 'g1', 'g2', 'w1', 'w2', 'w3', 'w4', 'w5', 'w6')}
print('points per pass', {PASSES[k]: int((SEG == k).sum()) for k in PASSES}, flush=True)

def rmse(pred, m): return float(((pred[m] - Bext[m]) ** 2).sum(1).mean().sqrt())
def m_t96(p, b, dd, by, bz): return torch.stack(t96([p, dd, by, bz] + [0.] * 6, PS, X, Y, Z), 1)
def m_t04(p, dd, by, bz, w): return torch.stack(t04([p, dd, by, bz] + w, PS, X, Y, Z), 1)

res = {'passes': PASSES, 'n_points': {PASSES[k]: int((SEG == k).sum()) for k in PASSES}}
with torch.no_grad():
    preds = {
        'IGRF only': torch.zeros_like(Bext),
        'T96 (OMNI)': m_t96(drv['pdyn'], None, drv['symh'], drv['imf_by'], drv['imf_bz']),
        'T96 clamped': m_t96(drv['pdyn'].clamp(0.5, 10), None, drv['symh'].clamp(-100, 20),
                             drv['imf_by'].clamp(-10, 10), drv['imf_bz'].clamp(-10, 10)),
        'T01 (OMNI)': torch.stack(t01([drv['pdyn'], drv['symh'], drv['imf_by'], drv['imf_bz'], drv['g1'], drv['g2']] + [0.] * 4, PS, X, Y, Z), 1),
        'T04 (OMNI)': m_t04(drv['pdyn'], drv['symh'], drv['imf_by'], drv['imf_bz'], [drv[f'w{i}'] for i in range(1, 7)]),
    }
res['fixed_models'] = {name: {PASSES[k]: rmse(p, SEG == k) for k in PASSES} for name, p in preds.items()}
for n, v in res['fixed_models'].items(): print(n, {a: round(b, 1) for a, b in v.items()}, flush=True)

# ---------- driver recalibration through the differentiable models (leave-one-pass-out)
def cal_pred(model, th):
    a, b, c, d = th
    dd = a * drv['symh'] + b; p = torch.exp(c) * drv['pdyn']
    if model == 'T96':
        return m_t96(p, None, dd, torch.exp(d) * drv['imf_by'], torch.exp(d) * drv['imf_bz'])
    return m_t04(p, dd, drv['imf_by'], drv['imf_bz'], [torch.exp(d) * drv[f'w{i}'] for i in range(1, 7)])

res['calibrated'] = {}
for model in ('T96', 'T04'):
    out = {}
    for k in PASSES:
        trn = torch.tensor(SEG != k); tst = SEG == k
        th = torch.tensor([1.0, 0.0, 0.0, 0.0], dtype=DT, requires_grad=True)
        opt = torch.optim.LBFGS([th], lr=1, max_iter=80, line_search_fn='strong_wolfe', tolerance_grad=1e-9)
        def cl():
            opt.zero_grad(); L = ((cal_pred(model, th)[trn] - Bext[trn]) ** 2).sum(1).mean(); L.backward(); return L
        t0 = time.perf_counter(); opt.step(cl)
        with torch.no_grad(): pr = cal_pred(model, th)
        out[PASSES[k]] = dict(test_rmse=rmse(pr, tst), train_rmse=rmse(pr, SEG != k), theta=th.detach().tolist(), time_s=time.perf_counter() - t0)
        print(model, 'cal, test', PASSES[k], round(out[PASSES[k]]['test_rmse'], 1), 'theta', np.round(th.detach().numpy(), 3), flush=True)
    res['calibrated'][model] = out

# ---------- hybrid: T04 + curl_x A_NN(x, drivers)
feat = torch.stack([X / 10, Y / 10, Z / 10, drv['symh'] / 100, torch.log(drv['pdyn']) / 3, drv['imf_bz'] / 20, drv['imf_by'] / 20], 1)
prior = preds['T04 (OMNI)']
class Net(torch.nn.Module):
    def __init__(s, w=64):
        super().__init__(); s.f = torch.nn.Sequential(torch.nn.Linear(7, w), torch.nn.Tanh(), torch.nn.Linear(w, w), torch.nn.Tanh(),
                                                      torch.nn.Linear(w, w), torch.nn.Tanh(), torch.nn.Linear(w, 3)).double()
    def forward(s, f): return s.f(f)
def curl(net, f, cg=True):
    f = f.detach().requires_grad_(True); A = net(f)
    J = [torch.autograd.grad(A[:, i].sum(), f, create_graph=cg, retain_graph=True)[0][:, :3] / 10 for i in range(3)]  # d/dx = (1/10) d/df
    return 100.0 * torch.stack([J[2][:, 1] - J[1][:, 2], J[0][:, 2] - J[2][:, 0], J[1][:, 0] - J[0][:, 1]], 1)
res['hybrid'] = {}
for lam in (0.1, 1.0, 10.0):
    out = {}
    for k in PASSES:
        torch.manual_seed(0)
        trn = torch.tensor(SEG != k); tst = SEG == k
        net = Net(); opt = torch.optim.Adam(net.parameters(), 2e-3); N = 2000
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, N)
        # collocation: training positions jittered by 1 Re with the same drivers (keeps the residual small off-track)
        fc = feat[trn].clone()
        for it in range(N):
            opt.zero_grad()
            r = curl(net, feat[trn])
            L = ((prior[trn] + r - Bext[trn]) ** 2).sum(1).mean()
            fj = fc.clone(); fj[:, :3] += 0.1 * torch.randn(len(fc), 3, dtype=DT)
            L = L + lam * (curl(net, fj) ** 2).sum(1).mean()
            L.backward(); opt.step(); sch.step()
        pr = prior + curl(net, feat, False).detach()
        out[PASSES[k]] = dict(test_rmse=rmse(pr, tst), train_rmse=rmse(pr, SEG != k))
        print('hybrid lam', lam, 'test', PASSES[k], round(out[PASSES[k]]['test_rmse'], 1), 'train', round(out[PASSES[k]]['train_rmse'], 1), flush=True)
    res['hybrid'][str(lam)] = out
json.dump(res, open('results_e11_real.json', 'w'), indent=1)
np.save('e11_index.npy', idx)
print('done')
