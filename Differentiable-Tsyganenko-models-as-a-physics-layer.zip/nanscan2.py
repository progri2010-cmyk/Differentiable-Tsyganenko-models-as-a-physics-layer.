import numpy as np, torch, sys
from tsyg.t96 import t96; from tsyg.t01 import t01; from tsyg.t04 import t04
name=sys.argv[1]; f = {'t96': t96, 't01': t01, 't04': t04}[name]
par = {'t96': [3.0, -50., 3.0, -4.0]+[0.]*6, 't01': [3.0, -50., 3.0, -4.0, 1.5, 3.0]+[0.]*4, 't04': [3.0,-50.,3.0,-4.0,.8,.9,1.1,1.2,1.3,1.4]}[name]
xs_, ys_ = np.meshgrid(np.linspace(-15, 15, 61), np.linspace(-25, 25, 51))
for lab, pts in (('eq', np.stack([xs_.ravel(), ys_.ravel(), 0*xs_.ravel()], 1)), ('mer', np.stack([xs_.ravel(), 0*xs_.ravel(), ys_.ravel()*0.8], 1))):
    pts = pts[np.linalg.norm(pts, axis=1) > 1.5]
    G = torch.tensor(pts).requires_grad_(True)
    B = torch.stack(f(par, 0.0, G[:,0], G[:,1], G[:,2]), 1)
    gG, = torch.autograd.grad(B.pow(2).sum(), G)
    bad = ~torch.isfinite(gG).all(1)
    print(lab, int(bad.sum()), pts[bad.numpy()][:6].tolist())
    if bad.any() and len(sys.argv) > 2:
        p = torch.tensor(pts[bad.numpy()][:1]).requires_grad_(True)
        with torch.autograd.detect_anomaly(check_nan=True):
            B = torch.stack(f(par, 0.0, p[:,0], p[:,1], p[:,2]), 1)
            try: B.pow(2).sum().backward()
            except Exception as e: print(e)
