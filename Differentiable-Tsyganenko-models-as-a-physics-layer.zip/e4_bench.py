"""E4: throughput, geopack scalar loop vs vectorized PyTorch (CPU, float64)."""
import numpy as np, torch, time, json
from geopack.t89 import t89 as t89_ref
import tsyg_torch as tt
torch.set_num_threads(2)
rng = np.random.default_rng(4); res = {'threads': torch.get_num_threads(), 'rows': []}
a = tt.t89_coeffs(3)
def best(fn, rep):
    ts = []
    for _ in range(rep):
        t0 = time.perf_counter(); fn(); ts.append(time.perf_counter() - t0)
    return min(ts)
for N in (100, 1000, 10_000, 100_000, 1_000_000):
    P = rng.uniform(-30, 8, (N, 3)); ps = 0.2
    X, Y, Z = (torch.tensor(P[:, k]) for k in range(3))
    t_torch = best(lambda: tt.t89(X, Y, Z, ps, a), 5 if N < 1e6 else 3)
    pos = torch.tensor(P)
    t_jac = best(lambda: tt.field_jacobian(lambda x, y, z: tt.t89(x, y, z, ps, a), pos), 3 if N < 1e6 else 1)
    if N <= 100_000:
        t_ref = best(lambda: [t89_ref(3, ps, *p) for p in P], 2); est = False
    else:
        t_ref = res['rows'][-1]['t_geopack_s'] * N / res['rows'][-1]['N']; est = True
    row = dict(N=N, t_geopack_s=t_ref, geopack_extrapolated=est, t_torch_s=t_torch, t_torch_jac_s=t_jac,
               speedup=t_ref / t_torch, Mpts_per_s=N / t_torch / 1e6)
    res['rows'].append(row); print(row)
json.dump(res, open('results_e4.json', 'w'), indent=1)
