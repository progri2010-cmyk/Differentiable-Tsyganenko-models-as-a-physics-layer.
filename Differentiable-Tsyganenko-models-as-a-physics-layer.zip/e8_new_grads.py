"""E8: autodiff of T96/T01/T04 w.r.t. driving parameters and position vs central finite differences;
NaN/Inf scan of the full Jacobian over a grid covering magnetosphere, boundary layer and solar wind;
inside-only accuracy vs geopack; throughput up to 1e5 points."""
import numpy as np, torch, json, time, warnings
warnings.filterwarnings('ignore'); torch.set_num_threads(2)
from tsyg.t96 import t96; from tsyg.t01 import t01; from tsyg.t04 import t04
from geopack import t96 as R96, t01 as R01, t04 as R04
MOD = {'t96': t96, 't01': t01, 't04': t04}; REF = {'t96': R96.t96, 't01': R01.t01, 't04': R04.t04}
rng = np.random.default_rng(8); res = {}
par0 = {'t96': [3.0, -50., 3.0, -4.0] + [0.]*6,
        't01': [3.0, -50., 3.0, -4.0, 1.5, 3.0] + [0.]*4,
        't04': [3.0, -50., 3.0, -4.0, 0.8, 0.9, 1.1, 1.2, 1.3, 1.4]}
npar = {'t96': 4, 't01': 6, 't04': 10}
names = {'t96': ['Pdyn', 'Dst', 'By', 'Bz'], 't01': ['Pdyn', 'Dst', 'By', 'Bz', 'G1', 'G2'],
         't04': ['Pdyn', 'Dst', 'By', 'Bz', 'W1', 'W2', 'W3', 'W4', 'W5', 'W6']}
for name in ('t96', 't01', 't04'):
    f = MOD[name]
    # interior points (2.5 < r < 12 Re, x > -14)
    P = []
    while len(P) < 400:
        p = rng.uniform([-14, -10, -8], [8, 10, 8]); r = np.linalg.norm(p)
        if 2.5 < r < 12: P.append(p)
    P = torch.tensor(np.array(P)); ps = 0.25
    th = torch.tensor(par0[name][:npar[name]], dtype=torch.float64, requires_grad=True)
    def B(theta, pos):
        prm = list(theta) + [0.] * (10 - len(theta))
        return torch.stack(f(prm, ps, pos[:, 0], pos[:, 1], pos[:, 2]), 1)
    Bv = B(th, P)
    t0 = time.perf_counter()
    # per-point Jacobian dB/dtheta: (N,3,p) via expanding theta per point
    thN = th.detach().expand(P.shape[0], -1).clone().requires_grad_(True)
    prm = [thN[:, k] for k in range(npar[name])] + [0.] * (10 - npar[name])
    BN = torch.stack(f(prm, ps, P[:, 0], P[:, 1], P[:, 2]), 1)
    JA = torch.stack([torch.autograd.grad(BN[:, i].sum(), thN, retain_graph=True)[0] for i in range(3)], 1)
    tad = time.perf_counter() - t0
    # finite-difference check per point. The models are piecewise (region switches, clamps), so a
    # stencil can straddle a junction; such points are detected by comparing two step sizes and
    # reported separately instead of being mixed into the error statistics.
    def fd5(fun, h):
        return (-fun(2*h) + 8*fun(h) - 8*fun(-h) + fun(-2*h)) / (12 * h)
    def check(AD, fun, h, scale):
        F1, F2 = fd5(fun, h), fd5(fun, h/4)
        kink = ((F1 - F2).abs() > 1e-5 * scale).any(-1)
        e = ((AD - F1).abs().max(-1).values / scale)
        ok = ~kink
        return dict(max_rel_smooth=float(e[ok].max()), median_rel=float(e[ok].median()),
                    n_points=int(len(e)), n_junction_points=int(kink.sum()))
    rel = []
    for k in range(npar[name]):
        h = 2e-3 * max(1., abs(par0[name][k]))
        def Bk(dh):
            t_ = th.detach().clone(); t_[k] += dh; return B(t_, P).detach()
        sc = JA[:, :, k].abs().max().item() + 1e-30
        rel.append(check(JA[:, :, k], Bk, h, sc))
    # spatial Jacobian
    pos = P.clone().requires_grad_(True)
    Bp = B(th.detach(), pos)
    JS = torch.stack([torch.autograd.grad(Bp[:, i].sum(), pos, retain_graph=True)[0] for i in range(3)], 1)
    sp = []
    for j in range(3):
        e = torch.zeros(3, dtype=torch.float64); e[j] = 1.
        Bs = lambda c: B(th.detach(), P + c * e).detach()
        sp.append(check(JS[:, :, j].detach(), Bs, 2e-3, JS[:, :, j].abs().max().item()))
    div = (JS[:, 0, 0] + JS[:, 1, 1] + JS[:, 2, 2]).detach()
    gnorm = JS.flatten(1).norm(dim=1).detach()
    # NaN scan over a big grid incl. boundary layer and solar wind
    g = np.stack(np.meshgrid(np.linspace(-14.7, 14.7, 31), np.linspace(-24.3, 24.3, 21), np.linspace(-19.1, 19.1, 21)), -1).reshape(-1, 3)
    g = g[np.linalg.norm(g, axis=1) > 1.5]
    # (i) 3-D grid at tilt 0.25 rad, (ii) equatorial plane z=0 and (iii) noon-midnight plane y=0 at tilt 0,
    # where coordinate singularities of the scalar code sit exactly on grid nodes
    xs_, ys_ = np.meshgrid(np.linspace(-15, 15, 61), np.linspace(-25, 25, 51))
    eq = np.stack([xs_.ravel(), ys_.ravel(), 0*xs_.ravel()], 1); mer = np.stack([xs_.ravel(), 0*xs_.ravel(), ys_.ravel()*0.8], 1)
    eq = eq[np.linalg.norm(eq, axis=1) > 1.5]; mer = mer[np.linalg.norm(mer, axis=1) > 1.5]
    nf_field = nf_grad = 0
    for pts, tilt in ((g, 0.25), (eq, 0.0), (mer, 0.0)):
        G = torch.tensor(pts).requires_grad_(True)
        thg = th.detach().clone().requires_grad_(True)
        prm = list(thg) + [0.] * (10 - len(thg))
        BG = torch.stack(f(prm, tilt, G[:, 0], G[:, 1], G[:, 2]), 1)
        gG, gth = torch.autograd.grad(BG.pow(2).sum(), (G, thg))
        nf_field += int((~torch.isfinite(BG)).sum()); nf_grad += int((~torch.isfinite(gG)).sum()) + int((~torch.isfinite(gth)).sum())
    g = np.vstack([g, eq, mer])
    res[name] = dict(param_names=names[name], dB_dparam_vs_FD=rel, max_rel_param_smooth=max(r['max_rel_smooth'] for r in rel), junction_points_param=[r['n_junction_points'] for r in rel],
                     spatial_jac_vs_FD=sp, max_rel_spatial_smooth=max(r['max_rel_smooth'] for r in sp),
                     divB_max_abs_nT_per_Re=float(div.abs().max()), divB_median_rel=float((div.abs() / gnorm).median()),
                     divB_max_rel=float((div.abs() / gnorm).max()),
                     grid_points=int(len(g)), grid_nonfinite_field=nf_field, grid_nonfinite_grad=nf_grad,
                     t_param_jacobian_400pts_s=tad)
    # interior-only accuracy vs geopack (random parameters)
    Pi = P.numpy(); n = len(Pi)
    pr = np.stack([rng.uniform(0.5, 10, n), rng.uniform(-150, 20, n), rng.uniform(-10, 10, n), rng.uniform(-10, 10, n)] +
                  [rng.uniform(0, 3, n) for _ in range(6)], 1)
    if name == 't96': pr[:, 4:] = 0
    if name == 't01': pr[:, 6:] = 0
    psi = rng.uniform(-0.6, 0.6, n)
    Rf = np.array([REF[name](pr[i], psi[i], *Pi[i]) for i in range(n)])
    O = torch.stack(f([torch.tensor(pr[:, k]) for k in range(10)], torch.tensor(psi), *[torch.tensor(Pi[:, k]) for k in range(3)]), 1).numpy()
    e = np.linalg.norm(O - Rf, axis=1); m = np.linalg.norm(Rf, axis=1)
    res[name].update(interior_max_abs_nT=float(e.max()), interior_max_rel=float((e / m).max()), interior_median_B_nT=float(np.median(m)))
    # throughput
    rows = []
    for Nn in (1000, 10000, 100000):
        Q = rng.uniform([-14, -10, -8], [8, 10, 8], (Nn, 3)); X = [torch.tensor(Q[:, k]) for k in range(3)]
        prm = par0[name]
        ts = []
        for _ in range(2):
            t0 = time.perf_counter(); f(prm, 0.2, *X); ts.append(time.perf_counter() - t0)
        k = min(Nn, 1000); t0 = time.perf_counter()
        for i in range(k): REF[name](prm, 0.2, *Q[i])
        tg = (time.perf_counter() - t0) * Nn / k
        rows.append(dict(N=Nn, t_torch_s=min(ts), t_geopack_s=tg, geopack_extrapolated=Nn > 1000, speedup=tg / min(ts)))
    res[name]['throughput'] = rows
    print(name, json.dumps(res[name], indent=0)[:1500], flush=True)
json.dump(res, open('results_e8_new_models.json', 'w'), indent=1)
