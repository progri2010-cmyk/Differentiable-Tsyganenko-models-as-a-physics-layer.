"""
E10: the differentiable Tsyganenko layer inside a physics-informed neural network.

Controlled experiment.  The "true" magnetosphere is T04 (TS05) under storm-time driving; sparse,
noisy B_ext measurements are taken along six spacecraft orbits.  The reconstruction models only
know T96, which differs structurally from T04, so the T96-T04 mismatch plays the role of the
model error one meets with real data.  Compared reconstructions:

  M1  T96 alone, driving parameters (Pdyn, Dst, By, Bz) fitted to the data through the
      differentiable layer (L-BFGS)
  M2  neural field alone: B = curl A_NN (divergence-free by construction), trained on the data
  M3  hybrid, frozen prior: B = T96(theta_M1) + curl A_NN, residual penalised at collocation points
  M4  hybrid, joint: as M3 but theta is trained together with the network, i.e. the gradient of
      the loss flows through the Tsyganenko model into its driving parameters

Error is measured against the true field on 20 000 points filling the inner magnetosphere,
split by distance from the nearest measurement.
"""
import numpy as np, torch, json, time, sys, warnings
warnings.filterwarnings('ignore'); torch.set_num_threads(2)
from tsyg import t96, t04
DT = torch.float64
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 0
SIGMA = float(sys.argv[2]) if len(sys.argv) > 2 else 2.0
rng = np.random.default_rng(100 + SEED); torch.manual_seed(SEED)
PS = 0.2
TRUE_T04 = [5.0, -80., 4.0, -8.0, 1.2, 1.5, 2.0, 2.0, 1.0, 2.0]
LAMBDA = 1e-3          # weight of the residual penalty |dB_NN|^2 at collocation points (hybrids)

def in_region(p, rmin=3.0):
    r = np.linalg.norm(p, axis=-1)
    return (r > rmin) & (r < 12) & (p[..., 0] > -14) & (p[..., 0] < 7) & (np.abs(p[..., 2]) < 8)

def orbits(n_orb=6, n_pts=260):
    P, L = [], []
    for k in range(n_orb):
        apo, peri = rng.uniform(10.5, 12.5), 2.5
        inc, argp, raan = np.radians(rng.uniform(0, 40)), rng.uniform(0, 2*np.pi), rng.uniform(0, 2*np.pi)
        E = np.linspace(0, 2*np.pi, n_pts, endpoint=False)
        a = (apo + peri) / 2; e = (apo - peri) / (apo + peri)
        r = a * (1 - e*np.cos(E)); nu = 2*np.arctan2(np.sqrt(1+e)*np.sin(E/2), np.sqrt(1-e)*np.cos(E/2))
        u = nu + argp
        xo, yo = r*np.cos(u), r*np.sin(u)
        x1, y1, z1 = xo, yo*np.cos(inc), yo*np.sin(inc)
        P.append(np.stack([x1*np.cos(raan) - y1*np.sin(raan), x1*np.sin(raan) + y1*np.cos(raan), z1], 1)); L.append(np.full(n_pts, k))
    P, L = np.vstack(P), np.concatenate(L)
    m = in_region(P, 2.5)
    return P[m], L[m]

def T(a): return torch.tensor(a, dtype=DT)
def truth(P): return torch.stack(t04(TRUE_T04, PS, *T(P).T), 1)
def t96f(theta, Pt):
    prm = [torch.exp(theta[0]), theta[1], theta[2], theta[3]] + [0.]*6
    return torch.stack(t96(prm, PS, Pt[:, 0], Pt[:, 1], Pt[:, 2]), 1)

# ---------------- data, test set, collocation points
Pd, Ld = orbits(); Pdt = T(Pd)
Bd_true = truth(Pd); Bd = Bd_true + SIGMA * torch.randn_like(Bd_true)
Pte = []
while len(Pte) < 20000:
    q = rng.uniform([-14, -12, -8], [7, 12, 8], (40000, 3)); Pte += list(q[in_region(q)])
Pte = np.array(Pte[:20000]); Ptt = T(Pte); Bte = truth(Pte).detach()
dmin = np.min(np.linalg.norm(Pte[:, None, :] - Pd[None, ::2, :], axis=-1), axis=1)
near, far = dmin < 1.5, dmin > 3.0
def colloc(n=2000):
    out = []
    while len(out) < n:
        q = rng.uniform([-14, -12, -8], [7, 12, 8], (4*n, 3)); out += list(q[in_region(q)])
    return T(np.array(out[:n]))

def metrics(Bp):
    e = (Bp - Bte).norm(dim=1).numpy()
    return dict(rmse_all=float(np.sqrt((e**2).mean())), rmse_near=float(np.sqrt((e[near]**2).mean())),
                rmse_far=float(np.sqrt((e[far]**2).mean())), p95_all=float(np.quantile(e, .95)),
                rel_all=float(np.sqrt((e**2).mean()) / Bte.norm(dim=1).pow(2).mean().sqrt()))

# ---------------- neural vector potential, B = SCALE * curl_s A(s), s = p / 10
class Net(torch.nn.Module):
    def __init__(self, w=64, depth=4):
        super().__init__()
        layers, d = [], 3
        for _ in range(depth): layers += [torch.nn.Linear(d, w), torch.nn.Tanh()]; d = w
        layers += [torch.nn.Linear(d, 3)]
        self.f = torch.nn.Sequential(*layers).double()
    def forward(self, p): return self.f(p / 10.0)
SCALE = 50.0
def curlA(net, P, create_graph=True):
    if not P.requires_grad:
        P = P.detach().requires_grad_(True)
    A = net(P)
    J = [torch.autograd.grad(A[:, i].sum(), P, create_graph=create_graph, retain_graph=True)[0] for i in range(3)]  # J[i][:, j] = dA_i/dp_j
    c = torch.stack([J[2][:, 1] - J[1][:, 2], J[0][:, 2] - J[2][:, 0], J[1][:, 0] - J[0][:, 1]], 1)
    return SCALE * 10.0 * c          # d/ds = 10 d/dp

def batched(fn, P, bs=4000):
    return torch.cat([fn(P[i:i+bs]).detach() for i in range(0, len(P), bs)])

res = dict(seed=SEED, sigma=SIGMA, n_data=int(len(Pd)), true_T04=TRUE_T04, tilt=PS,
           test_points=20000, n_near=int(near.sum()), n_far=int(far.sum()))
# M0 reference: T96 with the "true" Pdyn/Dst/By/Bz handed over from T04 (no fitting)
th_true = torch.tensor([np.log(TRUE_T04[0])] + TRUE_T04[1:4], dtype=DT)
B96_true = torch.cat([t96f(th_true, Ptt[i:i+4000]).detach() for i in range(0, 20000, 4000)])
res['M0_T96_true_drivers'] = metrics(B96_true)

# ---------------- M1: fit T96 drivers
t0 = time.perf_counter()
th = torch.tensor([np.log(2.0), -20., 0.5, 0.5], dtype=DT, requires_grad=True)
opt = torch.optim.LBFGS([th], lr=1, max_iter=300, tolerance_grad=1e-10, tolerance_change=1e-14, line_search_fn='strong_wolfe')
def cl():
    opt.zero_grad(); L = ((t96f(th, Pdt) - Bd)**2).mean(); L.backward(); return L
opt.step(cl)
th1 = th.detach().clone()
B96_fit = torch.cat([t96f(th1, Ptt[i:i+4000]).detach() for i in range(0, 20000, 4000)])
res['M1_T96_fit'] = dict(metrics(B96_fit), theta=[float(np.exp(th1[0])), *map(float, th1[1:])],
                         data_rmse=float(((t96f(th1, Pdt) - Bd)**2).mean().sqrt()), time_s=time.perf_counter() - t0)
print('M0', res['M0_T96_true_drivers'], '\nM1', res['M1_T96_fit'], flush=True)

# ---------------- generic NN training
def train(prior_fn, n_steps, joint_theta=None, lam=LAMBDA, label='', mask=None):
    net = Net()
    params = [{'params': net.parameters(), 'lr': 2e-3}]
    if joint_theta is not None: params.append({'params': [joint_theta], 'lr': 5e-3})
    opt = torch.optim.Adam(params)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, n_steps)
    Pc = colloc()
    hist = []; t0 = time.perf_counter()
    for it in range(n_steps):
        opt.zero_grad()
        Pm, Bm = (Pdt, Bd) if mask is None else (Pdt[mask], Bd[mask])
        pr = (prior_fn() if prior_fn is not None else 0.)
        if mask is not None and prior_fn is not None: pr = pr[mask]
        Bp = curlA(net, Pm) + pr
        Ld = ((Bp - Bm)**2).mean()
        L = Ld
        if lam > 0:
            idx = torch.randint(0, len(Pc), (500,))
            L = L + lam * (curlA(net, Pc[idx])**2).mean()
        L.backward(); opt.step(); sched.step()
        if it % 100 == 0 or it == n_steps - 1:
            hist.append((it, float(Ld.sqrt()))); print(label, it, round(float(Ld.sqrt()), 3), round(time.perf_counter() - t0, 1), flush=True)
    return net, hist, time.perf_counter() - t0

N_STEPS = 3000
# M2: neural field only (no Tsyganenko knowledge), pure data fit
net2, h2, tm2 = train(None, N_STEPS, lam=0.0, label='M2')   # no shrinkage toward zero: B_ext itself is not small
B2 = batched(lambda P: curlA(net2, P, False), Ptt)
res['M2_NN_only'] = dict(metrics(B2), final_data_rmse=h2[-1][1], time_s=tm2)
print('M2', res['M2_NN_only'], flush=True)

# M3: hybrid with frozen fitted prior. The residual penalty lambda is chosen by hold-out validation:
# the network is trained on five orbits and scored on the sixth, then retrained on all six.
B96d = t96f(th1, Pdt).detach()
val = torch.tensor(Ld == Ld.max()); trn = ~val
sel = {}
for lam in (1e-3, 1e-2, 1e-1, 1.0, 10.0):
    netv, _, _ = train(lambda: B96d, N_STEPS, lam=lam, label=f'sel{lam:g}', mask=trn)
    Bv = B96d[val] + curlA(netv, Pdt[val], False).detach()
    sel[lam] = float(((Bv - Bd[val])**2).mean().sqrt())
    print('lambda', lam, 'val rmse', sel[lam], flush=True)
sel[0.0] = float(((B96d[val] - Bd[val])**2).mean().sqrt())     # prior alone on the held-out orbit
LAM = min((k for k in sel if k > 0), key=lambda k: sel[k])
res['lambda_selection_val_rmse'] = {str(k): v for k, v in sel.items()}; res['lambda_chosen'] = LAM
net3, h3, tm3 = train(lambda: B96d, N_STEPS, lam=LAM, label='M3')
B3 = B96_fit + batched(lambda P: curlA(net3, P, False), Ptt)
res['M3_hybrid_frozen'] = dict(metrics(B3), final_data_rmse=h3[-1][1], time_s=tm3, lam=LAM)
print('M3', res['M3_hybrid_frozen'], flush=True)

# M4: hybrid, joint training of the network and the T96 drivers (gradient through Tsyganenko)
th4 = th1.clone().requires_grad_(True)
N4 = 1000
net4, h4, tm4 = train(lambda: t96f(th4, Pdt), N4, joint_theta=th4, lam=LAM, label='M4')
th4d = th4.detach()
B4 = torch.cat([t96f(th4d, Ptt[i:i+4000]).detach() for i in range(0, 20000, 4000)]) + batched(lambda P: curlA(net4, P, False), Ptt)
res['M4_hybrid_joint'] = dict(metrics(B4), theta=[float(np.exp(th4d[0])), *map(float, th4d[1:])],
                              final_data_rmse=h4[-1][1], time_s=tm4, steps=N4)
print('M4', res['M4_hybrid_joint'], flush=True)

# divergence check of the learned residual (should be ~0 by construction)
Pq = Ptt[:2000].detach().requires_grad_(True)
dB = curlA(net3, Pq)
div = sum(torch.autograd.grad(dB[:, i].sum(), Pq, retain_graph=True)[0][:, i] for i in range(3))
res['divB_residual_max_nT_per_Re'] = float(div.abs().max())
torch.save(dict(net2=net2.state_dict(), net3=net3.state_dict(), net4=net4.state_dict(), th1=th1, th4=th4d), f'pinn_models_s{SEED}_sig{SIGMA:g}.pt')
np.save(f'pinn_data_s{SEED}.npy', np.column_stack([Pd, Ld]))
json.dump(res, open(f'results_e10_s{SEED}_sig{SIGMA:g}.json', 'w'), indent=1)
print('done', res['divB_residual_max_nT_per_Re'])
